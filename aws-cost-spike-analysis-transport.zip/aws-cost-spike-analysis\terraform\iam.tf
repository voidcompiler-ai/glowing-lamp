data "aws_iam_policy_document" "lambda_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

locals {
  lambda_basic_policy = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  member_role_arn_any = "arn:${local.partition}:iam::*:role/${var.member_role_name}"
}

# ------------------------------ Dedupe ------------------------------------- #
resource "aws_iam_role" "dedupe" {
  name               = "${var.name_prefix}-dedupe"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
}

resource "aws_iam_role_policy_attachment" "dedupe_logs" {
  role       = aws_iam_role.dedupe.name
  policy_arn = local.lambda_basic_policy
}

resource "aws_iam_role_policy" "dedupe" {
  role = aws_iam_role.dedupe.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["dynamodb:GetItem", "dynamodb:PutItem"]
      Resource = aws_dynamodb_table.anomalies.arn
    }]
  })
}

# ------------------------------ Agent -------------------------------------- #
resource "aws_iam_role" "agent" {
  name               = "${var.name_prefix}-agent"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
}

resource "aws_iam_role_policy_attachment" "agent_logs" {
  role       = aws_iam_role.agent.name
  policy_arn = local.lambda_basic_policy
}

resource "aws_iam_role_policy" "agent" {
  role = aws_iam_role.agent.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "InvokeClaude"
        Effect   = "Allow"
        Action   = ["bedrock:InvokeModel"]
        Resource = [
          "arn:${local.partition}:bedrock:*::foundation-model/anthropic.*",
          "arn:${local.partition}:bedrock:*:${local.account_id}:inference-profile/*",
        ]
      },
      {
        Sid      = "QueryCur"
        Effect   = "Allow"
        Action   = ["athena:StartQueryExecution", "athena:GetQueryExecution", "athena:GetQueryResults", "athena:StopQueryExecution"]
        Resource = aws_athena_workgroup.rca.arn
      },
      {
        Sid    = "ReadCurCatalog"
        Effect = "Allow"
        Action = ["glue:GetDatabase", "glue:GetTable", "glue:GetPartitions", "glue:GetPartition"]
        Resource = [
          "arn:${local.partition}:glue:${var.aws_region}:${local.account_id}:catalog",
          aws_glue_catalog_database.cur.arn,
          aws_glue_catalog_table.cur.arn,
        ]
      },
      {
        Sid      = "ListBucket"
        Effect   = "Allow"
        Action   = ["s3:ListBucket", "s3:GetBucketLocation"]
        Resource = aws_s3_bucket.data.arn
      },
      {
        Sid      = "ReadCurData"
        Effect   = "Allow"
        Action   = ["s3:GetObject"]
        Resource = ["${aws_s3_bucket.data.arn}/cur/*", "${aws_s3_bucket.data.arn}/athena-results/*"]
      },
      {
        Sid      = "WriteResultsAndReports"
        Effect   = "Allow"
        Action   = ["s3:PutObject", "s3:AbortMultipartUpload"]
        Resource = ["${aws_s3_bucket.data.arn}/athena-results/*", "${aws_s3_bucket.data.arn}/reports/*"]
      },
      {
        Sid      = "AssumeMemberReadRole"
        Effect   = "Allow"
        Action   = ["sts:AssumeRole"]
        Resource = local.member_role_arn_any
      },
    ]
  })
}

# ------------------------------ Notify ------------------------------------- #
resource "aws_iam_role" "notify" {
  name               = "${var.name_prefix}-notify"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
}

resource "aws_iam_role_policy_attachment" "notify_logs" {
  role       = aws_iam_role.notify.name
  policy_arn = local.lambda_basic_policy
}

resource "aws_iam_role_policy" "notify" {
  role = aws_iam_role.notify.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject"]
        Resource = "${aws_s3_bucket.data.arn}/reports/*"
      },
      {
        Effect   = "Allow"
        Action   = ["s3:PutObject"]
        Resource = "${aws_s3_bucket.data.arn}/notifications/*"
      },
      {
        Effect   = "Allow"
        Action   = ["ses:SendEmail"]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["ssm:GetParameter"]
        Resource = [aws_ssm_parameter.freshservice_enabled.arn, aws_ssm_parameter.freshservice_domain.arn]
      },
      {
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue"]
        Resource = aws_secretsmanager_secret.freshservice_api_key.arn
      },
    ]
  })
}

# -------------------- Read-only role in the member account ----------------- #
# In the sandbox this lives in the same account as the pipeline. In production
# the same role is rolled out to every member account with a StackSet.
resource "aws_iam_role" "member_read" {
  name = var.member_role_name
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { AWS = aws_iam_role.agent.arn }
    }]
  })
}

resource "aws_iam_role_policy" "member_read" {
  role = aws_iam_role.member_read.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "cloudtrail:LookupEvents",
        "config:DescribeConfigurationRecorders",
        "config:DescribeConfigurationRecorderStatus",
        "config:GetResourceConfigHistory",
        "cloudwatch:GetMetricStatistics",
        "cloudwatch:GetMetricData",
        "cloudwatch:ListMetrics",
        "tag:GetResources",
      ]
      Resource = "*"
    }]
  })
}

# ------------------------- Step Functions, EventBridge --------------------- #
resource "aws_iam_role" "sfn" {
  name = "${var.name_prefix}-sfn"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { Service = "states.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "sfn" {
  role = aws_iam_role.sfn.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["lambda:InvokeFunction"]
      Resource = [aws_lambda_function.dedupe.arn, aws_lambda_function.agent.arn, aws_lambda_function.notify.arn]
    }]
  })
}

resource "aws_iam_role" "events" {
  name = "${var.name_prefix}-events"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { Service = "events.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "events" {
  role = aws_iam_role.events.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["states:StartExecution"]
      Resource = aws_sfn_state_machine.rca.arn
    }]
  })
}
