"""Generate the hand-positioned, animated MCP architecture diagram as one HTML file.

Each box shows the AWS service (bold) and what it does (italic). A box may carry a middle
line for a resource name; build_deployed_diagram.py uses that. Each arrow is labelled with
the data that travels along it; a label may span several lines (separated by newlines).
"""
import html
import sys

W, H = 2370, 1070
NODE_H = 64
LINE = 16  # spacing between lines of an arrow label

STYLE = {
    "trigger": ("#FFE4B5", "#8B4513", "#4a2500"),
    "compute": ("#D8C8FF", "#4B2E9E", "#24114f"),
    "mcp": ("#FFF3B0", "#8A6D00", "#3d3000"),
    "data": ("#BFE9DD", "#0F6E56", "#04342C"),
    "email": ("#CFE4FA", "#185FA5", "#042C53"),
    "people": ("#EDEDED", "#444444", "#111111"),
    "opt": ("#F7F7F7", "#999999", "#555555"),
}

# id: (x, y, width, style, service, [resource name,] purpose)
NODES = {
    "cad": (40, 120, 250, "trigger", "💰 AWS Cost Anomaly Detection", "spots the unusual spend"),
    "eb": (450, 120, 230, "trigger", "📡 Amazon EventBridge", "passes the anomaly event on"),
    "sfn": (810, 120, 230, "trigger", "🔄 AWS Step Functions", "runs the investigation steps"),
    "dedupe": (1190, 120, 230, "compute", "⚡ AWS Lambda", "skips anomalies already handled"),
    "ddb": (1570, 120, 230, "data", "🗃️ Amazon DynamoDB", "remembers anomalies seen"),
    "bedrock": (410, 350, 230, "compute", "🧠 Amazon Bedrock (Claude)", "reasons over the evidence"),
    "agent": (810, 350, 230, "mcp", "🤖 AgentCore Runtime agent", "finds the root cause"),
    "gw": (1210, 350, 240, "mcp", "🚪 AgentCore Gateway", "one secured entry to all tools"),
    "m1": (1640, 270, 260, "mcp", "💵 Billing and Cost Mgmt MCP", "anomaly and cost details"),
    "m2": (1640, 346, 260, "mcp", "🔎 Athena MCP", "resource-level CUR queries"),
    "m3": (1640, 422, 260, "mcp", "📝 CloudTrail MCP", "who changed what, and when"),
    "m4": (1640, 498, 260, "mcp", "📈 CloudWatch MCP", "whether usage really grew"),
    "m5": (1640, 574, 260, "mcp", "🏷️ AWS API MCP", "Config history and owner tags"),
    "d1": (2070, 308, 260, "data", "💰 Cost Explorer and CUR 2.0", "billing data down to resource ID"),
    "d2": (2070, 422, 260, "data", "📝 AWS CloudTrail, Org trail", "API activity in all 65 accounts"),
    "d3": (2070, 498, 260, "data", "📈 Amazon CloudWatch", "metrics from all 65 accounts"),
    "d4": (2070, 574, 260, "data", "⚙️ AWS Config and tags", "settings history and ownership"),
    "analyst": (1210, 540, 240, "people", "🧑‍💻 FinOps analyst", "asks follow-up questions in Claude"),
    "ch": (1210, 670, 240, "opt", "☁️ CloudHealth MCP", "reallocated cost views"),
    "notify": (115, 780, 230, "compute", "📨 AWS Lambda", "picks who to tell, builds email"),
    "s3": (810, 780, 230, "data", "📦 Amazon S3", "keeps every root-cause report"),
    "fs": (30, 910, 200, "opt", "🎫 FreshService", "optional ITSM ticket"),
    "ses": (250, 910, 230, "email", "✉️ Amazon SES", "delivers the email"),
    "app": (1120, 870, 240, "people", "👥 App team", "owner from the resource tag"),
    "fin": (1120, 950, 240, "people", "👤 FinOps team", "untagged or low confidence"),
}

# (x, y, width, height, title)
GROUPS = [
    (24, 80, 672, 124, "1 · Trigger"),
    (794, 80, 1022, 124, "2 · Orchestration"),
    (394, 310, 662, 124, "3 · AgentCore Runtime"),
    (1624, 230, 292, 428, "4 · Open-source MCP servers"),
    (2054, 230, 292, 428, "Org-wide sources · read-only"),
    (24, 740, 1032, 290, "5 · Notification"),
]


def side(node, where, offset=0):
    x, y, w = NODES[node][:3]
    return {
        "l": (x, y + NODE_H / 2 + offset), "r": (x + w, y + NODE_H / 2 + offset),
        "t": (x + w / 2 + offset, y), "b": (x + w / 2 + offset, y + NODE_H),
    }[where]


def line(a, b):
    return f"M{a[0]} {a[1]} L{b[0]} {b[1]}"


def hcurve(a, b):
    mid = (a[0] + b[0]) / 2
    return f"M{a[0]} {a[1]} C{mid} {a[1]} {mid} {b[1]} {b[0]} {b[1]}"


def poly(*points):
    return "M" + " L".join(f"{x} {y}" for x, y in points)


# (path, kind, label, label_x, first_line_y, anchor)
EDGES = [
    (line(side("cad", "r"), side("eb", "l")), "flow",
     "1 · anomaly event:\naccount, service,\nusage type, $ impact", 370, 112, "middle"),
    (line(side("eb", "r"), side("sfn", "l")), "flow", "2 · same event,\nunchanged", 745, 128, "middle"),
    (line(side("sfn", "r"), side("dedupe", "l")), "flow", "3 · the event;\nreturns proceed\nor skip", 1115, 112, "middle"),
    (line(side("dedupe", "r"), side("ddb", "l")), "flow", "anomaly ID,\nimpact, run count", 1495, 128, "middle"),
    (line(side("sfn", "b", 45), side("agent", "t", 45)), "flow", "4 · anomaly details,\nattempt number", 982, 264, "start"),
    (line(side("agent", "l"), side("bedrock", "r")), "flow",
     "5 · evidence so far;\nreturns next tool\ncall or final report", 725, 342, "middle"),
    (line(side("agent", "r"), side("gw", "l")), "flow",
     "6 · tool call:\nname + arguments\n(SQL, resource ID)", 1125, 342, "middle"),
    (hcurve(side("gw", "r"), side("m1", "l")), "flow", "forwards the call;\nresults return\nthe same way", 1462, 262, "start"),
    (hcurve(side("gw", "r"), side("m2", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("gw", "r"), side("m3", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("gw", "r"), side("m4", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("gw", "r"), side("m5", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("m1", "r"), side("d1", "l", -12)), "flow", "read-only\nAWS queries", 1985, 258, "middle"),
    (hcurve(side("m2", "r"), side("d1", "l", 12)), "flow", "", 0, 0, "middle"),
    (line(side("m3", "r"), side("d2", "l")), "flow", "", 0, 0, "middle"),
    (line(side("m4", "r"), side("d3", "l")), "flow", "", 0, 0, "middle"),
    (line(side("m5", "r"), side("d4", "l")), "flow", "", 0, 0, "middle"),
    (line(side("agent", "b"), side("s3", "t")), "flow", "7 · root-cause report\n(JSON)", 937, 592, "start"),
    (poly(side("sfn", "b", -65), (860, 246), (230, 246), side("notify", "t")), "flow",
     "8 · anomaly details + S3 location of the report", 545, 236, "middle"),
    (line(side("s3", "l"), side("notify", "r")), "flow", "full report (JSON)", 577, 802, "middle"),
    (line((280, 844), (345, 910)), "flow", "9 · from, to, subject,\nHTML body", 334, 866, "start"),
    (hcurve(side("ses", "r"), side("app", "l")), "flow",
     "the email, when owner is\nknown and confidence high", 800, 880, "middle"),
    (hcurve(side("ses", "r"), side("fin", "l")), "flow", "the email, in all\nother cases", 800, 990, "middle"),
    (line((185, 844), (130, 910)), "opt", "ticket: subject,\ndescription", 138, 870, "end"),
    (line(side("analyst", "t"), side("gw", "b")), "opt", "follow-up\ntool calls", 1342, 474, "start"),
    (line(side("ch", "t"), side("analyst", "b")), "opt", "reallocated cost views", 1342, 648, "start"),
]

LEGEND = [
    ("mcp", "New: AgentCore and open-source MCP servers"),
    ("trigger", "Trigger and orchestration"),
    ("compute", "Compute and model"),
    ("data", "Data stores and sources"),
    ("email", "Email"),
    ("people", "People"),
    ("opt", "Optional"),
]


def build():
    out = [f'<svg viewBox="0 60 {W} {H - 60}" role="img" aria-labelledby="t d">',
           '<title id="t">Target architecture with open-source MCP servers</title>',
           '<desc id="d">A cost anomaly flows from Cost Anomaly Detection through EventBridge and Step Functions to an '
           'investigation agent on Bedrock AgentCore Runtime. The agent reasons with Claude on Bedrock and calls five '
           'open-source AWS MCP servers through an AgentCore Gateway. The report is saved to S3 and a Lambda emails '
           'the owning app team or the FinOps team. Each arrow is labelled with the data it carries.</desc>',
           '<defs><marker id="head" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" '
           'orient="auto-start-reverse"><path d="M1 1 L9 5 L1 9 Z" fill="context-stroke"/></marker></defs>']
    for x, y, w, h, title in GROUPS:
        out.append(f'<rect class="group" x="{x}" y="{y}" width="{w}" height="{h}" rx="10"/>')
        out.append(f'<text class="gtitle" x="{x + 14}" y="{y + 23}">{html.escape(title)}</text>')
    for path, kind, *_ in EDGES:
        out.append(f'<path class="{kind}" d="{path}" marker-end="url(#head)"/>')
    for _, kind, label, lx, ly, anchor in EDGES:
        if label:
            spans = "".join(f'<tspan x="{lx}" dy="{LINE if index else 0}">{html.escape(text)}</tspan>'
                            for index, text in enumerate(label.split("\n")))
            out.append(f'<text class="elabel" x="{lx}" y="{ly}" text-anchor="{anchor}">{spans}</text>')
    for x, y, w, style, title, *lines in NODES.values():
        fill, stroke, color = STYLE[style]
        dash = ' stroke-dasharray="6 5"' if style == "opt" else ""
        width = 3 if style == "mcp" else 2
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{NODE_H}" rx="8" fill="{fill}" stroke="{stroke}" '
                   f'stroke-width="{width}"{dash}/>')
        out.append(f'<text class="ntitle" x="{x + w / 2}" y="{y + 27}" fill="{color}">{html.escape(title)}</text>')
        for index, text in enumerate(lines):
            css = "npurpose" if index == len(lines) - 1 else "nname"
            out.append(f'<text class="{css}" x="{x + w / 2}" y="{y + 47 + 20 * index}" fill="{color}">'
                       f'{html.escape(text)}</text>')
    out.append("</svg>")
    legend = "".join(f'<span style="--c1:{STYLE[k][0]};--c2:{STYLE[k][1]}">{html.escape(text)}</span>'
                     for k, text in LEGEND)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FinOps cost-spike pipeline: target architecture with open-source MCP servers</title>
<style>
  body {{ margin:0; background:#ffffff; color:#1b1b1b; font-family:"Segoe UI",system-ui,Arial,sans-serif; }}
  header {{ padding:18px 28px 6px; }}
  h1 {{ font-size:22px; font-weight:600; margin:0 0 4px; }}
  p.sub {{ margin:0; color:#5c5c5c; font-size:14px; max-width:1200px; }}
  .legend {{ display:flex; flex-wrap:wrap; gap:6px 18px; padding:8px 28px 0; font-size:13px; color:#5c5c5c; }}
  .legend span::before {{ content:""; display:inline-block; width:12px; height:12px; border-radius:3px;
    margin-right:6px; vertical-align:-1px; border:1.5px solid var(--c2); background:var(--c1); }}
  .wrap {{ padding:6px 16px 24px; overflow-x:auto; }}
  svg {{ display:block; width:100%; min-width:1500px; height:auto; font-family:inherit; }}
  .group {{ fill:#fafafa; stroke:#bdbdbd; stroke-width:1.2; }}
  .gtitle {{ font-size:14px; font-weight:600; fill:#5c5c5c; }}
  .ntitle {{ font-size:14px; font-weight:600; text-anchor:middle; }}
  .nname {{ font-size:12.5px; text-anchor:middle; font-family:Consolas,"Cascadia Mono",monospace; }}
  .npurpose {{ font-size:13px; font-style:italic; text-anchor:middle; }}
  .elabel {{ font-size:12.5px; fill:#3a2a66; paint-order:stroke; stroke:#ffffff; stroke-width:5px; stroke-linejoin:round; }}
  path.flow {{ fill:none; stroke:#4b4b4b; stroke-width:2.2; stroke-dasharray:9 7; stroke-linejoin:round; }}
  path.opt {{ fill:none; stroke:#8a8a8a; stroke-width:1.8; stroke-dasharray:2 6; stroke-linecap:round; }}
  @media (prefers-reduced-motion: no-preference) {{
    path.flow {{ animation: flow 0.9s linear infinite; }}
  }}
  @keyframes flow {{ to {{ stroke-dashoffset:-32; }} }}
</style>
</head>
<body>
<header>
  <h1>FinOps cost-spike pipeline: target architecture with open-source MCP servers</h1>
  <p class="sub">Proposed design for a company AWS account. Not deployed: Bedrock AgentCore is not available in the
  Pluralsight sandbox. Each box names the service in bold and what it does in italics. Each arrow is labelled with the
  data it carries, and the numbers 1 to 9 give the order. Moving arrows are the path of one anomaly; dotted grey
  arrows are optional or supporting links.</p>
</header>
<div class="legend">{legend}</div>
<div class="wrap">
{chr(10).join(out)}
</div>
</body>
</html>
"""


if __name__ == "__main__":
    with open(sys.argv[1], "w", encoding="utf-8") as handle:
        handle.write(build())
    print("written", sys.argv[1])
