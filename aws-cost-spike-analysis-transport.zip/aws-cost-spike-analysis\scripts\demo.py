"""Sandbox demo driver for the cost-spike root-cause pipeline.

  py scripts/demo.py load-cur          upload a synthetic CUR 2.0 dataset with three planted spikes
  py scripts/demo.py change            make the real capacity changes on the demo tables (CloudTrail evidence)
  py scripts/demo.py revert            put the demo tables back to baseline capacity
  py scripts/demo.py fire <scenario>   send a simulated anomaly and wait for the result
                                       scenarios: orders, sessions, savingsplan

The CUR data is synthetic because a sandbox has no billing export. The two
DynamoDB spikes refer to real tables whose capacity really is changed, so the
CloudTrail, CloudWatch and tag evidence the agent finds is genuine.
"""
import argparse
import datetime as dt
import gzip
import json
import pathlib
import random
import subprocess
import sys
import time

import boto3

ROOT = pathlib.Path(__file__).resolve().parent.parent
BASELINE_DAYS = 14
BASE_CAPACITY = 5
SPIKE_CAPACITY = 1000
WCU_HR, RCU_HR = 0.00065, 0.00013
M5_XLARGE_HR = 0.192
SP_DISCOUNT = 0.28
FAKE_ACCOUNTS = ["111111111111", "222222222222"]


def tf_outputs():
    raw = subprocess.run(["terraform", f"-chdir={ROOT / 'terraform'}", "output", "-json"],
                         check=True, capture_output=True, text=True, shell=(sys.platform == "win32")).stdout
    return {k: v["value"] for k, v in json.loads(raw).items()}


def cfn_outputs(profile, region, pipeline_stack="finops-rca", fixture_stack="finops-rca-sandbox-fixture"):
    """The same settings, read from the CloudFormation stacks instead of Terraform."""
    session = boto3.Session(profile_name=profile, region_name=region)
    cfn = session.client("cloudformation")

    def outputs(stack):
        described = cfn.describe_stacks(StackName=stack)["Stacks"][0]
        return {o["OutputKey"]: o["OutputValue"] for o in described.get("Outputs", [])}

    fixture, pipeline = outputs(fixture_stack), outputs(pipeline_stack)
    return {
        "aws_profile": profile,
        "region": region,
        "account_id": session.client("sts").get_caller_identity()["Account"],
        "bucket": pipeline["DataBucketName"],          # reports and notifications
        "cur_bucket": fixture["FixtureBucketName"],    # synthetic CUR data
        "state_machine_arn": pipeline["StateMachineArn"],
        "demo_orders_table_arn": fixture["DemoOrdersTableArn"],
        "demo_sessions_table_arn": fixture["DemoSessionsTableArn"],
        "demo_owner_email": fixture["DemoOwnerEmail"],
        # The CloudFormation rule matches real aws.ce events only, so start the workflow directly.
        "start_directly": True,
    }


def today_utc():
    return dt.datetime.now(dt.timezone.utc).date()


def row(day, account, product, usage_type, operation, resource_id, usage, cost, *, item_type="Usage",
        region="us-east-1", tags=None, term="OnDemand", sp_arn="", description=""):
    return {
        "line_item_usage_start_date": f"{day} 00:00:00",
        "line_item_usage_end_date": f"{day + dt.timedelta(days=1)} 00:00:00",
        "line_item_usage_account_id": account,
        "line_item_product_code": product,
        "line_item_usage_type": usage_type,
        "line_item_operation": operation,
        "line_item_resource_id": resource_id,
        "line_item_line_item_type": item_type,
        "line_item_line_item_description": description,
        "line_item_usage_amount": round(usage, 4),
        "line_item_unblended_cost": round(cost, 6),
        "product_region_code": region,
        "pricing_term": term,
        "savings_plan_savings_plan_a_r_n": sp_arn,
        "resource_tags": tags or {},
    }


def build_rows(out):
    account = out["account_id"]
    orders, sessions = out["demo_orders_table_arn"], out["demo_sessions_table_arn"]
    owner = out["demo_owner_email"]
    sp_arn = f"arn:aws:savingsplans::{account}:savingsplan/11111111-2222-3333-4444-555555555555"
    instances = [f"i-0a1b2c3d4e5f6000{n}" for n in range(6)]
    rng = random.Random(42)
    spike_day = today_utc()
    rows = []

    def jitter(value):
        return value * rng.uniform(0.96, 1.04)

    for offset in range(BASELINE_DAYS, -1, -1):
        day = spike_day - dt.timedelta(days=offset)
        spike = offset == 0

        # Steady background spend in other accounts and services.
        for fake in FAKE_ACCOUNTS:
            for n in range(3):
                rows.append(row(day, fake, "AmazonEC2", "BoxUsage:m5.large", "RunInstances",
                                f"i-0f{fake[:4]}aaaa000{n}", 24, jitter(2.304),
                                tags={"user_owner": f"team-{fake[:3]}@example.com"}))
            rows.append(row(day, fake, "AmazonS3", "TimedStorage-ByteHrs", "StandardStorage",
                            f"data-lake-{fake}", 5000, jitter(3.83), tags={"user_owner": f"data-{fake[:3]}@example.com"}))
            rows.append(row(day, fake, "AmazonRDS", "InstanceUsage:db.r5.large", "CreateDBInstance:0002",
                            f"arn:aws:rds:us-east-1:{fake}:db:core-db", 24, jitter(6.0),
                            tags={"user_owner": f"dba-{fake[:3]}@example.com"}))
        rows.append(row(day, account, "AmazonS3", "TimedStorage-ByteHrs", "StandardStorage",
                        "app-assets-bucket", 2500, jitter(1.92), tags={"user_owner": "web-team@example.com"}))
        rows.append(row(day, account, "AWSLambda", "Lambda-GB-Second", "Invoke",
                        f"arn:aws:lambda:us-east-1:{account}:function:order-api", 30000, jitter(0.5),
                        tags={"user_owner": owner}))

        # Scenario 1: tagged DynamoDB table, write capacity raised.
        wcu = SPIKE_CAPACITY if spike else BASE_CAPACITY
        rows.append(row(day, account, "AmazonDynamoDB", "WriteCapacityUnit-Hrs", "CommittedThroughput", orders,
                        wcu * 24, wcu * 24 * WCU_HR, tags={"user_owner": owner, "user_app": "orders"},
                        description="$0.00065 per hour for units of write capacity"))
        rows.append(row(day, account, "AmazonDynamoDB", "ReadCapacityUnit-Hrs", "CommittedThroughput", orders,
                        BASE_CAPACITY * 24, BASE_CAPACITY * 24 * RCU_HR, tags={"user_owner": owner, "user_app": "orders"},
                        description="$0.00013 per hour for units of read capacity"))

        # Scenario 2: DynamoDB table with no owner tag, read capacity raised.
        rcu = SPIKE_CAPACITY if spike else BASE_CAPACITY
        rows.append(row(day, account, "AmazonDynamoDB", "ReadCapacityUnit-Hrs", "CommittedThroughput", sessions,
                        rcu * 24, rcu * 24 * RCU_HR, tags={"user_app": "sessions"},
                        description="$0.00013 per hour for units of read capacity"))
        rows.append(row(day, account, "AmazonDynamoDB", "WriteCapacityUnit-Hrs", "CommittedThroughput", sessions,
                        BASE_CAPACITY * 24, BASE_CAPACITY * 24 * WCU_HR, tags={"user_app": "sessions"},
                        description="$0.00065 per hour for units of write capacity"))

        # Scenario 3: Savings Plan expires; identical EC2 usage bills on demand.
        on_demand = 24 * M5_XLARGE_HR
        ec2_tags = {"user_owner": "platform-team@example.com", "user_app": "batch"}
        for instance in instances:
            if spike:
                rows.append(row(day, account, "AmazonEC2", "BoxUsage:m5.xlarge", "RunInstances", instance, 24,
                                on_demand, tags=ec2_tags, description="$0.192 per On Demand Linux m5.xlarge Instance Hour"))
            else:
                rows.append(row(day, account, "AmazonEC2", "BoxUsage:m5.xlarge", "RunInstances", instance, 24,
                                on_demand, item_type="SavingsPlanCoveredUsage", tags=ec2_tags, sp_arn=sp_arn,
                                description="$0.192 per On Demand Linux m5.xlarge Instance Hour"))
                rows.append(row(day, account, "AmazonEC2", "BoxUsage:m5.xlarge", "RunInstances", instance, 24,
                                -on_demand, item_type="SavingsPlanNegation", tags=ec2_tags, sp_arn=sp_arn,
                                description="SavingsPlanNegation used by AccountId and UsageSku"))
        # Scenario 4: an Auto Scaling group runs 2 instances normally and 12 on the spike day.
        # No single instance stands out; only the group total shows the spike.
        asg_tags = {"aws_autoscaling_group_name": "web-asg", "user_owner": "web-team@example.com"}
        for n in range(12 if spike else 2):
            rows.append(row(day, account, "AmazonEC2", "BoxUsage:c5.large", "RunInstances",
                            f"i-0asg{'new' if n >= 2 else 'old'}00000{n:02d}", 24, 24 * 0.085, tags=asg_tags,
                            description="$0.085 per On Demand Linux c5.large Instance Hour"))

        # Scenario 5: cross-zone data transfer, which carries no resource ID in the CUR.
        gigabytes = 5000 if spike else 100
        for operation in ("InterZone-In", "InterZone-Out"):
            rows.append(row(day, account, "AmazonEC2", "DataTransfer-Regional-Bytes", operation, "",
                            gigabytes / 2, gigabytes / 2 * 0.01, description="$0.010 per GB - regional data transfer"))

        if not spike:
            rows.append(row(day, account, "ComputeSavingsPlans", "ComputeSP:1yrNoUpfront", "", sp_arn, 24,
                            len(instances) * on_demand * (1 - SP_DISCOUNT), item_type="SavingsPlanRecurringFee",
                            term="", sp_arn=sp_arn, description="1 year No Upfront Compute Savings Plan"))
    return rows


def scenarios(out):
    account, region = out["account_id"], out["region"]
    ec2_base = 6 * 24 * M5_XLARGE_HR * (1 - SP_DISCOUNT)
    ec2_spike = 6 * 24 * M5_XLARGE_HR
    return {
        "orders": ("Amazon DynamoDB", "WriteCapacityUnit-Hrs",
                   BASE_CAPACITY * 24 * WCU_HR, SPIKE_CAPACITY * 24 * WCU_HR),
        "sessions": ("Amazon DynamoDB", "ReadCapacityUnit-Hrs",
                     BASE_CAPACITY * 24 * RCU_HR, SPIKE_CAPACITY * 24 * RCU_HR),
        "savingsplan": ("Amazon Elastic Compute Cloud - Compute", "BoxUsage:m5.xlarge", ec2_base, ec2_spike),
        "autoscale": ("Amazon Elastic Compute Cloud - Compute", "BoxUsage:c5.large", 2 * 24 * 0.085, 12 * 24 * 0.085),
        "datatransfer": ("Amazon Elastic Compute Cloud - Compute", "DataTransfer-Regional-Bytes", 1.0, 50.0),
    }, account, region


def cmd_load_cur(session, out):
    s3 = session.client("s3")
    bucket = out.get("cur_bucket", out["bucket"])
    existing = s3.list_objects_v2(Bucket=bucket, Prefix="cur/data/").get("Contents", [])
    if existing:
        s3.delete_objects(Bucket=bucket, Delete={"Objects": [{"Key": o["Key"]} for o in existing]})
    by_period = {}
    for item in build_rows(out):
        by_period.setdefault(item["line_item_usage_start_date"][:7], []).append(item)
    for period, items in sorted(by_period.items()):
        body = gzip.compress("\n".join(json.dumps(i) for i in items).encode())
        key = f"cur/data/billing_period={period}/synthetic-00001.json.gz"
        s3.put_object(Bucket=bucket, Key=key, Body=body)
        print(f"uploaded {len(items):4d} line items to s3://{bucket}/{key}")
    # Remember the spike day so anomalies fired after midnight UTC still match the data.
    s3.put_object(Bucket=bucket, Key="demo/spike_day", Body=str(today_utc()).encode())


def set_capacity(session, out, capacity):
    ddb = session.client("dynamodb")
    plan = [(out["demo_orders_table_arn"], "write"), (out["demo_sessions_table_arn"], "read")]
    for arn, kind in plan:
        name = arn.split("/")[-1]
        current = ddb.describe_table(TableName=name)["Table"]["ProvisionedThroughput"]
        read = capacity if kind == "read" else current["ReadCapacityUnits"]
        write = capacity if kind == "write" else current["WriteCapacityUnits"]
        if (read, write) == (current["ReadCapacityUnits"], current["WriteCapacityUnits"]):
            print(f"{name}: already at read={read} write={write}")
            continue
        ddb.update_table(TableName=name, ProvisionedThroughput={"ReadCapacityUnits": read, "WriteCapacityUnits": write})
        print(f"{name}: set read={read} write={write}")


def cmd_fire(session, out, scenario, wait):
    table, account, region = scenarios(out)
    service, usage_type, expected, actual = table[scenario]
    started = dt.datetime.now(dt.timezone.utc)
    anomaly_id = f"sim-{scenario}-{started.strftime('%Y%m%d%H%M%S')}"
    spike_day = session.client("s3").get_object(
        Bucket=out.get("cur_bucket", out["bucket"]), Key="demo/spike_day")["Body"].read().decode()
    detail = {
        "accountName": "sandbox",
        "anomalyId": anomaly_id,
        "anomalyStartDate": f"{spike_day}T00:00:00Z",
        "anomalyEndDate": f"{spike_day}T00:00:00Z",
        "anomalyScore": {"maxScore": 0.92, "currentScore": 0.92},
        "dimensionValue": service,
        "impact": {
            "maxImpact": round(actual - expected, 2),
            "totalActualSpend": round(actual, 2),
            "totalExpectedSpend": round(expected, 2),
            "totalImpact": round(actual - expected, 2),
            "totalImpactPercentage": round((actual - expected) / expected * 100, 1),
        },
        "monitorArn": f"arn:aws:ce::{account}:anomalymonitor/simulated",
        "rootCauses": [{"linkedAccount": account, "linkedAccountName": "sandbox", "region": region,
                        "service": service, "usageType": usage_type}],
        "subscriptionId": "simulated",
        "subscriptionName": "simulated",
    }
    sfn = session.client("stepfunctions")
    execution = None
    if out.get("start_directly"):
        execution = sfn.start_execution(
            stateMachineArn=out["state_machine_arn"], name=anomaly_id,
            input=json.dumps({"source": "aws.ce", "detail-type": "Anomaly Detected", "detail": detail}))["executionArn"]
    else:
        result = session.client("events").put_events(Entries=[{
            "Source": "finops.simulated.ce", "DetailType": "Anomaly Detected", "Detail": json.dumps(detail)}])
        if result["FailedEntryCount"]:
            sys.exit(f"put_events failed: {result['Entries']}")
    print(f"fired simulated anomaly {anomaly_id}")
    if not wait:
        return

    deadline = time.time() + 120
    while not execution and time.time() < deadline:
        time.sleep(3)
        for candidate in sfn.list_executions(stateMachineArn=out["state_machine_arn"], maxResults=10)["executions"]:
            if candidate["startDate"] >= started - dt.timedelta(seconds=5):
                described = sfn.describe_execution(executionArn=candidate["executionArn"])
                if anomaly_id in described["input"]:
                    execution = candidate["executionArn"]
                    break
    if not execution:
        sys.exit("no Step Functions execution started for the event")
    print(f"execution {execution.split(':')[-1]} running", end="", flush=True)
    while True:
        described = sfn.describe_execution(executionArn=execution)
        if described["status"] != "RUNNING":
            break
        print(".", end="", flush=True)
        time.sleep(5)
    seconds = (described["stopDate"] - described["startDate"]).total_seconds()
    print(f"\nstatus: {described['status']} after {seconds:.0f}s")
    if described["status"] != "SUCCEEDED":
        history = sfn.get_execution_history(executionArn=execution, reverseOrder=True, maxResults=5)
        print(json.dumps(history["events"], indent=2, default=str)[:3000])

    s3 = session.client("s3")
    bucket = out["bucket"]
    out_dir = ROOT / "out" / anomaly_id
    out_dir.mkdir(parents=True, exist_ok=True)
    for prefix in (f"reports/{anomaly_id}/", f"notifications/{anomaly_id}/"):
        for obj in s3.list_objects_v2(Bucket=bucket, Prefix=prefix).get("Contents", []):
            target = out_dir / obj["Key"].split("/")[-1]
            s3.download_file(bucket, obj["Key"], str(target))
    print(f"report and rendered emails saved to {out_dir}")

    for path in out_dir.glob("2*.json"):
        record = json.loads(path.read_text())
        report = record["report"]
        print(f"\ncategory: {report['cause_category']}   confidence: {report['confidence']}   "
              f"tool calls: {len(record['tool_calls'])}   mode: {record.get('investigation_mode')}   "
              f"tokens: {record.get('token_usage')}")
        if record.get("hybrid_stages"):
            print(f"hybrid stages: {record['hybrid_stages']}")
        print(f"summary: {report['summary']}")
        for resource in report["resources"]:
            print(f"  - {resource['resource_id']}  owner={resource.get('owner_contact')} "
                  f"({resource.get('owner_tag_status')})  by={resource.get('changed_by')}")
        for gap in report["data_gaps"]:
            print(f"  gap: {gap}")
    delivery = out_dir / "delivery.json"
    if delivery.exists():
        for note in json.loads(delivery.read_text())["notifications"]:
            print(f"\nnotification -> {note['audience']}: to={note['to']} cc={note['cc']}\n"
                  f"  subject: {note['subject']}\n  email: {note['email']['status']}  ticket: {note['ticket']['status']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("load-cur")
    sub.add_parser("change")
    sub.add_parser("revert")
    fire = sub.add_parser("fire")
    fire.add_argument("scenario", choices=["orders", "sessions", "savingsplan", "autoscale", "datatransfer"])
    fire.add_argument("--no-wait", action="store_true")
    parser.add_argument("--cfn-profile", help="use the CloudFormation stacks, with this AWS CLI profile, instead of Terraform")
    parser.add_argument("--region", default="us-east-1")
    args = parser.parse_args()

    out = cfn_outputs(args.cfn_profile, args.region) if args.cfn_profile else tf_outputs()
    session = boto3.Session(profile_name=out["aws_profile"], region_name=out["region"])
    if args.command == "load-cur":
        cmd_load_cur(session, out)
    elif args.command == "change":
        set_capacity(session, out, SPIKE_CAPACITY)
    elif args.command == "revert":
        set_capacity(session, out, BASE_CAPACITY)
    else:
        cmd_fire(session, out, args.scenario, not args.no_wait)


if __name__ == "__main__":
    main()
