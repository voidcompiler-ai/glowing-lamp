"""Generate the hand-positioned, animated diagram of the resources deployed in the sandbox.

Reuses the drawing code in build_mcp_diagram.py and swaps in this diagram's boxes and arrows.
Each box shows the AWS service (bold), the deployed resource (monospace) and its purpose (italic).
Each arrow is labelled with the data that travels along it.
"""
import re
import sys

import build_mcp_diagram as b

b.W, b.H = 2320, 1180
b.NODE_H = 84
b.STYLE["secure"] = ("#FFD6D6", "#A32D2D", "#501313")

# id: (x, y, width, style, service, resource name, purpose)
b.NODES = {
    "cad": (40, 120, 250, "trigger", "💰 AWS Cost Anomaly Detection", "simulated event (sandbox)", "spots the unusual spend"),
    "eb": (450, 120, 240, "trigger", "📡 Amazon EventBridge rule", "finops-rca-anomaly-detected", "starts the workflow"),
    "sfn": (820, 120, 230, "trigger", "🔄 AWS Step Functions", "finops-rca", "runs the steps in order"),
    "dedupe": (1200, 120, 250, "compute", "⚡ AWS Lambda", "finops-rca-dedupe", "skips anomalies already handled"),
    "ddb": (1600, 120, 230, "data", "🗃️ Amazon DynamoDB", "finops-rca-anomalies", "remembers anomalies seen"),
    "bedrock": (400, 370, 240, "compute", "🧠 Amazon Bedrock", "Claude Haiku 4.5", "interprets the evidence"),
    "agent": (810, 370, 250, "compute", "🤖 AWS Lambda", "finops-rca-agent", "gathers evidence, finds the cause"),
    "athena": (1260, 290, 240, "data", "🔎 Amazon Athena", "workgroup finops-rca", "runs SQL over the billing data"),
    "glue": (1610, 290, 250, "data", "📚 AWS Glue Data Catalog", "finops_rca_cur.cur2", "describes the CUR table"),
    "s3cur": (1970, 290, 250, "data", "📦 Amazon S3", "cur/", "holds CUR 2.0 data (synthetic)"),
    "role": (1260, 590, 240, "secure", "🔑 AWS IAM role", "FinOpsRcaReadOnly", "read-only access to the account"),
    "ct": (1690, 440, 250, "email", "📝 AWS CloudTrail", "event history", "who changed what, and when"),
    "cw": (1690, 540, 250, "email", "📈 Amazon CloudWatch", "metrics", "whether usage really grew"),
    "cfg": (1690, 640, 250, "opt", "⚙️ AWS Config", "not recording here", "settings history"),
    "tag": (1690, 740, 250, "email", "🏷️ Resource Groups Tagging API", "live tags", "who owns the resource"),
    "demo": (2030, 590, 250, "data", "🗃️ Amazon DynamoDB", "demo-orders, demo-sessions", "test resources being investigated"),
    "s3rep": (820, 600, 230, "data", "📦 Amazon S3", "reports/", "keeps every root-cause report"),
    "notify": (105, 880, 250, "compute", "📨 AWS Lambda", "finops-rca-notify", "picks who to tell, builds email"),
    "fs": (560, 770, 220, "opt", "🎫 FreshService", "toggle is off", "optional ITSM ticket"),
    "ses": (560, 880, 220, "email", "✉️ Amazon SES", "email identity", "delivers the email"),
    "ssm": (30, 1030, 230, "secure", "🎚️ SSM Parameter Store", "/finops-rca/freshservice/*", "ticket on/off switch, domain"),
    "sec": (275, 1030, 230, "secure", "🔐 AWS Secrets Manager", "finops-rca/freshservice-api-key", "holds the FreshService key"),
    "s3not": (560, 1030, 230, "data", "📦 Amazon S3", "notifications/", "copy of each email sent"),
    "app": (1040, 830, 250, "people", "👥 App team", "from the Owner tag", "gets tagged, high-confidence spikes"),
    "fin": (1040, 930, 250, "people", "👤 FinOps team", "FinOps mailbox", "gets untagged or uncertain ones"),
}

# (x, y, width, height, title)
b.GROUPS = [
    (24, 80, 682, 144, "1 · Trigger"),
    (804, 80, 1042, 144, "2 · Orchestration"),
    (384, 330, 692, 144, "3 · Investigation"),
    (1674, 400, 622, 444, "Member-account evidence · read-only"),
    (24, 730, 782, 404, "4 · Notification"),
]

side, line, hcurve, poly = b.side, b.line, b.hcurve, b.poly

# (path, kind, label, label_x, first_line_y, anchor)
b.EDGES = [
    (line(side("cad", "r"), side("eb", "l")), "flow",
     "1 · anomaly event:\naccount, service,\nusage type, $ impact", 370, 122, "middle"),
    (line(side("eb", "r"), side("sfn", "l")), "flow", "2 · same event,\nunchanged", 755, 138, "middle"),
    (line(side("sfn", "r"), side("dedupe", "l")), "flow", "3 · the event;\nreturns proceed\nor skip", 1125, 122, "middle"),
    (line(side("dedupe", "r"), side("ddb", "l")), "flow", "anomaly ID,\nimpact, run count", 1525, 138, "middle"),
    (line(side("sfn", "b", 45), side("agent", "t", 45)), "flow", "4 · anomaly details,\nattempt number", 992, 302, "start"),
    (hcurve(side("agent", "r"), side("athena", "l")), "flow",
     "5 · SQL: account,\nusage type, dates;\nreturns cost rows", 1250, 276, "end"),
    (line(side("athena", "r"), side("glue", "l")), "flow", "looks up\ntable layout", 1555, 308, "middle"),
    (line(side("glue", "r"), side("s3cur", "l")), "flow", "reads CUR\nfiles", 1915, 308, "middle"),
    (hcurve(side("agent", "r"), side("role", "l")), "flow",
     "6 · assume role;\nreturns temporary\nread-only access", 1250, 660, "end"),
    (hcurve(side("role", "r"), side("ct", "l")), "flow",
     "resource ID + time\nwindow; returns events,\nmetrics, history, tags", 1380, 546, "middle"),
    (hcurve(side("role", "r"), side("cw", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("role", "r"), side("cfg", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("role", "r"), side("tag", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("ct", "r"), side("demo", "l", -14)), "opt", "", 0, 0, "middle"),
    (hcurve(side("cw", "r"), side("demo", "l")), "opt", "", 0, 0, "middle"),
    (hcurve(side("tag", "r"), side("demo", "l", 14)), "opt", "", 0, 0, "middle"),
    (line(side("agent", "l"), side("bedrock", "r")), "flow",
     "7 · evidence summary;\nreturns root cause,\nconfidence, actions", 725, 372, "middle"),
    (line(side("agent", "b"), side("s3rep", "t")), "flow", "8 · root-cause report\n(JSON)", 947, 522, "start"),
    (poly(side("sfn", "b", -65), (870, 266), (170, 266), side("notify", "t", -60)), "flow",
     "9 · anomaly details + S3 location of the report", 520, 256, "middle"),
    (poly(side("s3rep", "l"), (290, 642), side("notify", "t", 60)), "flow", "full report (JSON)", 555, 632, "middle"),
    (line(side("notify", "r"), side("ses", "l")), "flow", "10 · from, to, subject,\nHTML body", 457, 898, "middle"),
    (poly(side("notify", "t", 100), (330, 812), side("fs", "l")), "opt",
     "ticket: subject, description,\nrequester", 445, 788, "middle"),
    (line((150, 964), (145, 1030)), "flow", "reads toggle,\ndomain, API key", 138, 992, "end"),
    (line((240, 964), (390, 1030)), "flow", "", 0, 0, "middle"),
    (line((330, 964), (675, 1030)), "flow", "copy of email +\ndelivery record", 580, 986, "start"),
    (hcurve(side("ses", "r"), side("app", "l")), "flow",
     "the email, when owner is\nknown and confidence high", 910, 842, "middle"),
    (hcurve(side("ses", "r"), side("fin", "l")), "flow", "the email, in all\nother cases", 910, 990, "middle"),
]

b.LEGEND = [
    ("trigger", "Trigger and orchestration"),
    ("compute", "Compute and model"),
    ("data", "Data stores"),
    ("secure", "Access and secrets"),
    ("email", "AWS services read or called"),
    ("people", "People"),
    ("opt", "Inactive in this sandbox"),
]

TITLE = "FinOps cost-spike pipeline: deployed architecture"
SUB = ("Snapshot of sandbox account 012125623936, us-east-1. Each box names the AWS service in bold, the deployed "
       "resource in monospace, and what it does in italics. Each arrow is labelled with the data it carries, and the "
       "numbers 1 to 10 give the order. Moving arrows are the path of one anomaly; dotted grey arrows are optional or "
       "reference links. The three S3 boxes are prefixes of one bucket, finops-rca-012125623936-us-east-1. Each "
       "Lambda, the EventBridge rule and the state machine has its own IAM role.")
DESC = ("A simulated cost anomaly flows through an EventBridge rule and a Step Functions state machine to a dedupe "
        "Lambda, an agent Lambda and a notify Lambda. The agent queries the CUR through Athena and Glue, assumes a "
        "read-only role to read CloudTrail, CloudWatch, Config and tags, asks Claude Haiku 4.5 on Bedrock to "
        "interpret the evidence, and saves a report to S3. The notify Lambda emails the app team or FinOps through "
        "SES. Each arrow is labelled with the data it carries.")


def build():
    page = b.build()
    page = page.replace("FinOps cost-spike pipeline: target architecture with open-source MCP servers", TITLE)
    page = page.replace("Target architecture with open-source MCP servers", "Deployed architecture")
    page = re.sub(r'<p class="sub">.*?</p>', f'<p class="sub">{SUB}</p>', page, flags=re.S)
    page = re.sub(r'<desc id="d">.*?</desc>', f'<desc id="d">{DESC}</desc>', page, flags=re.S)
    return page


if __name__ == "__main__":
    with open(sys.argv[1], "w", encoding="utf-8") as handle:
        handle.write(build())
    print("written", sys.argv[1])
