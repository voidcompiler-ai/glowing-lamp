# Prerequisites: what must already exist in AWS

What has to be in place before deploying the CloudFormation templates in `cloudformation/` to
the Organization, and what the templates create themselves. Deploy steps are in
`cloudformation/README.md`; background is in `HANDOFF.md`.

**How far this is verified:** the templates were deployed once, to a single sandbox account
with synthetic billing data. Nothing here has been checked against the Organization. Items
marked "assumed" come from AWS documentation or from how the code was written, not from a test.

## 1. Must exist before deploying

| # | What | Where | Used for | Template parameter |
|---|---|---|---|---|
| 1 | CUR 2.0 data export (AWS Data Exports) | Its S3 bucket | The billing data every investigation reads | `CurBucketName`, `CurPrefix` |
| 2 | Athena table over that export, in a Glue database | Pipeline account, us-east-1 | Querying the export | `CurDatabase`, `CurTable` |
| 3 | Cost Anomaly Detection monitor | Management account | Produces the anomaly events that start the pipeline | none |
| 4 | Bedrock access to the chosen Claude model | Pipeline account, us-east-1 | Writing the root-cause report | `ModelId` |
| 5 | Verified SES identity for the From address, with SES out of its sandbox | Pipeline account, us-east-1 | Sending the emails | `SesSenderEmail` |
| 6 | S3 bucket for deployment artifacts | Pipeline account, us-east-1 | The package step uploads the Lambda code there | none (given to `aws cloudformation package`) |
| 7 | Trusted access for CloudFormation StackSets | The Organization | Rolling the read-only role out to the accounts | none |

"Pipeline account" is whichever account runs `pipeline.yaml`: the management account, or a
FinOps tooling account that receives forwarded events. That choice is still open.

## 2. The CUR 2.0 export in detail

The pipeline does not create, change or copy an export. It reads the existing one.

**Settings the export needs:**

| Setting | Needed | Why |
|---|---|---|
| Table | CUR 2.0, standard data export | The queries use CUR 2.0 column names |
| Include resource IDs | On | Without it there is no `line_item_resource_id`, and no resource can be named |
| Format | Parquet | Required by AWS's documented Athena setup for Data Exports |
| File versioning | Overwrite existing data export file | Required by the same setup; otherwise costs are counted more than once |
| Time granularity | Daily or hourly | Monthly is too coarse to see when a spike began |
| Columns | All, or at least the 15 listed below | An export created with a column subset may lack some |

**Columns the pipeline reads:**

`line_item_usage_start_date`, `line_item_usage_end_date`, `line_item_usage_account_id`,
`line_item_product_code`, `line_item_usage_type`, `line_item_operation`,
`line_item_resource_id`, `line_item_line_item_type`, `line_item_line_item_description`,
`line_item_usage_amount`, `line_item_unblended_cost`, `product_region_code`, `pricing_term`,
`savings_plan_savings_plan_a_r_n`, `resource_tags`, plus the partition column `billing_period`.

**The Athena table.** Data Exports does not create one automatically. AWS documents a Glue
crawler pointed at `s3://<bucket>/<prefix>/<export-name>/data`. If the CUR is already queried
in Athena, for example through Cloud Intelligence Dashboards, reuse that table.

**Mapping it to the template:**

| Parameter | Value |
|---|---|
| `CurDatabase` | Glue database that holds the table |
| `CurTable` | The table name |
| `CurBucketName` | Bucket the export is delivered to |
| `CurPrefix` | `<prefix>/<export-name>/`, ending with a slash |
| `CurKmsKeyArn` | The key ARN if the export is encrypted with a customer managed key, otherwise empty |

**Three assumptions to check in Athena before deploying.** The code depends on them and they
are not confirmed for a real export:

- The partition column is named `billing_period`, with values like `2026-11`.
- `resource_tags` is a map, not a struct.
- Owner tag keys look like `user_owner`.

```sql
SHOW COLUMNS IN your_database.your_table;
```

```sql
SELECT billing_period, resource_tags FROM your_database.your_table WHERE cardinality(resource_tags) > 0 LIMIT 5;
```

If the second query fails on `cardinality`, `resource_tags` is not a map and the code in
`lambda/agent/handler.py` needs adjusting before the first run.

## 3. Needed only in some cases

| What | When |
|---|---|
| KMS key policy allowing the investigation role to decrypt | The export is encrypted with a customer managed key |
| Bucket policy on the CUR bucket allowing the investigation role to read | The export is in a different account from the pipeline |
| Lake Formation grant of `SELECT` on the CUR table to the investigation role | Lake Formation governs that table |
| FreshService account, domain and API key | The ticket toggle is turned on |

The investigation role is `<NamePrefix>-agent`, `finops-rca-agent` by default. It does not
exist until `pipeline.yaml` is deployed, so add the bucket policy, key policy and Lake
Formation grant after that deployment and before the first run.

## 4. Helpful but not required

| What | Effect if missing |
|---|---|
| Owner tags on resources, holding a contact email address | The report goes to FinOps as untagged |
| Those tag keys activated as cost allocation tags | Tags are absent from the CUR, so a resource that no longer exists cannot be traced to an owner |
| AWS Config recording in member accounts | No settings history; the report lists it as a data gap |

CloudTrail needs no setup. The pipeline reads the 90-day event history that every account has
by default.

## 5. Values to have ready

| Value | For |
|---|---|
| Pipeline account ID | `member-role.yaml` (`PipelineAccountId`) |
| Management account ID | `pipeline.yaml` (`EventSourceAccountId`), only if the pipeline runs in another account |
| Organization ID (`o-...`) | `pipeline.yaml` (`OrganizationId`) |
| Organizational unit IDs and pilot account IDs | The StackSet rollout of the member role |
| Bedrock model ID or inference profile ID | `ModelId` |
| FinOps mailbox and From address | `FinOpsEmail`, `SesSenderEmail` |
| Owner tag keys | `OwnerTagKeys` |

## 6. What the templates create

Nothing in this list needs to exist beforehand.

| Template | Creates |
|---|---|
| `pipeline.yaml` | Reports bucket; dedupe table (DynamoDB); Athena workgroup; three Lambda functions and their log groups; Step Functions state machine; EventBridge rule; five IAM roles; two SSM parameters; the FreshService secret, created empty |
| `member-role.yaml` | The read-only role `FinOpsRcaReadOnly`, in each account it is deployed to |
| `event-forwarder.yaml` | A forwarding rule and its role, in the management account. Only when the pipeline runs elsewhere |

`cloudformation/sandbox/fixture.yaml` is for throwaway test accounts only. It creates
stand-ins for items 1 and 2 above. Never deploy it in the Organization.
