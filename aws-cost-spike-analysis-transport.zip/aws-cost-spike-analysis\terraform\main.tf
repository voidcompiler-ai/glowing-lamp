terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.4"
    }
  }
}

provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile
}

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition
  bucket     = "${var.name_prefix}-${local.account_id}-${var.aws_region}"
  cur_table  = "cur2"

  # Subset of the CUR 2.0 schema that the agent queries.
  cur_columns = [
    ["line_item_usage_start_date", "timestamp"],
    ["line_item_usage_end_date", "timestamp"],
    ["line_item_usage_account_id", "string"],
    ["line_item_product_code", "string"],
    ["line_item_usage_type", "string"],
    ["line_item_operation", "string"],
    ["line_item_resource_id", "string"],
    ["line_item_line_item_type", "string"],
    ["line_item_line_item_description", "string"],
    ["line_item_usage_amount", "double"],
    ["line_item_unblended_cost", "double"],
    ["product_region_code", "string"],
    ["pricing_term", "string"],
    ["savings_plan_savings_plan_a_r_n", "string"],
    ["resource_tags", "map<string,string>"],
  ]
}

# --------------------------------------------------------------------------- #
# Storage: CUR data (synthetic in the sandbox), Athena results, reports, mail
# --------------------------------------------------------------------------- #
resource "aws_s3_bucket" "data" {
  bucket        = local.bucket
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "data" {
  bucket                  = aws_s3_bucket.data.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "data" {
  bucket = aws_s3_bucket.data.id
  rule {
    id     = "expire-athena-results"
    status = "Enabled"
    filter {
      prefix = "athena-results/"
    }
    expiration {
      days = 7
    }
  }
}

resource "aws_dynamodb_table" "anomalies" {
  name         = "${var.name_prefix}-anomalies"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "anomaly_id"

  attribute {
    name = "anomaly_id"
    type = "S"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = true
  }
}

# --------------------------------------------------------------------------- #
# Athena over the CUR. In production, point the table at the real CUR 2.0
# export (Parquet) instead; the column names and partition are the same.
# --------------------------------------------------------------------------- #
resource "aws_glue_catalog_database" "cur" {
  name = replace("${var.name_prefix}_cur", "-", "_")
}

resource "aws_glue_catalog_table" "cur" {
  name          = local.cur_table
  database_name = aws_glue_catalog_database.cur.name
  table_type    = "EXTERNAL_TABLE"

  parameters = {
    "classification"                          = "json"
    "projection.enabled"                      = "true"
    "projection.billing_period.type"          = "date"
    "projection.billing_period.format"        = "yyyy-MM"
    "projection.billing_period.range"         = "2026-01,NOW"
    "projection.billing_period.interval"      = "1"
    "projection.billing_period.interval.unit" = "MONTHS"
    "storage.location.template"               = "s3://${aws_s3_bucket.data.bucket}/cur/data/billing_period=$${billing_period}/"
  }

  partition_keys {
    name = "billing_period"
    type = "string"
  }

  storage_descriptor {
    location      = "s3://${aws_s3_bucket.data.bucket}/cur/data/"
    input_format  = "org.apache.hadoop.mapred.TextInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat"

    ser_de_info {
      serialization_library = "org.openx.data.jsonserde.JsonSerDe"
    }

    dynamic "columns" {
      for_each = local.cur_columns
      content {
        name = columns.value[0]
        type = columns.value[1]
      }
    }
  }
}

resource "aws_athena_workgroup" "rca" {
  name          = var.name_prefix
  force_destroy = true

  configuration {
    enforce_workgroup_configuration = true
    bytes_scanned_cutoff_per_query  = 10737418240 # 10 GB guard rail per query

    result_configuration {
      output_location = "s3://${aws_s3_bucket.data.bucket}/athena-results/"
    }
  }
}

# --------------------------------------------------------------------------- #
# FreshService: toggle and settings
# --------------------------------------------------------------------------- #
resource "aws_ssm_parameter" "freshservice_enabled" {
  name  = "/${var.name_prefix}/freshservice/enabled"
  type  = "String"
  value = tostring(var.freshservice_enabled)

  lifecycle {
    ignore_changes = [value] # flipped by operators, not by Terraform
  }
}

resource "aws_ssm_parameter" "freshservice_domain" {
  name  = "/${var.name_prefix}/freshservice/domain"
  type  = "String"
  value = var.freshservice_domain
}

resource "aws_secretsmanager_secret" "freshservice_api_key" {
  name                    = "${var.name_prefix}/freshservice-api-key"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret_version" "freshservice_api_key" {
  secret_id     = aws_secretsmanager_secret.freshservice_api_key.id
  secret_string = "REPLACE_ME"

  lifecycle {
    ignore_changes = [secret_string] # the real key is set out of band
  }
}
