"""Route a root-cause report to the owning team or to FinOps.

Routing is plain code. An app team is emailed directly only when the report is
high confidence, the resource carries a valid owner tag, the cause is something
a team can act on, and shadow mode is off. Everything else goes to FinOps.
"""
import base64
import html
import json
import os
import urllib.error
import urllib.request

import boto3

BUCKET = os.environ["BUCKET"]
FINOPS_EMAIL = os.environ["FINOPS_EMAIL"]
SENDER_EMAIL = os.environ["SENDER_EMAIL"]
SHADOW_MODE = os.environ.get("SHADOW_MODE", "true").lower() == "true"
FS_ENABLED_PARAM = os.environ["FRESHSERVICE_ENABLED_PARAM"]
FS_DOMAIN_PARAM = os.environ["FRESHSERVICE_DOMAIN_PARAM"]
FS_SECRET_ID = os.environ["FRESHSERVICE_SECRET_ID"]

s3 = boto3.client("s3")
ses = boto3.client("sesv2")
ssm = boto3.client("ssm")
secrets = boto3.client("secretsmanager")


def esc(value):
    return html.escape("" if value is None else str(value))


def usd(value):
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return "n/a"


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #
TH = 'style="text-align:left;padding:6px 10px;border-bottom:2px solid #ccc;font-size:13px"'
TD = 'style="padding:6px 10px;border-bottom:1px solid #e5e5e5;font-size:13px;vertical-align:top"'


def render(record, resources, audience, reasons):
    report, anomaly = record["report"], record["anomaly"]
    impact = anomaly.get("impact") or {}
    rows = []
    for r in resources:
        owner = r.get("owner_contact") or "none"
        if r.get("owner_tag_status") != "valid":
            owner = f"{owner} ({r.get('owner_tag_status', 'missing')} owner tag)"
        rows.append(
            f"<tr><td {TD}><code>{esc(r.get('resource_id'))}</code><br>"
            f"{esc(r.get('service'))} &middot; {esc(r.get('usage_type'))}<br>"
            f"Account {esc(r.get('account_id'))} &middot; {esc(r.get('region'))}</td>"
            f"<td {TD}>{usd(r.get('baseline_daily_usd'))} &rarr; {usd(r.get('spike_daily_usd'))} per day</td>"
            f"<td {TD}>{esc(r.get('what_changed'))}<br>"
            f"By: {esc(r.get('changed_by') or 'unknown')}<br>At: {esc(r.get('changed_at') or 'unknown')}</td>"
            f"<td {TD}>{esc(owner)}</td></tr>"
        )
    resource_table = (
        f'<table style="border-collapse:collapse;width:100%"><tr><th {TH}>Resource</th><th {TH}>Daily cost</th>'
        f"<th {TH}>What changed</th><th {TH}>Owner</th></tr>{''.join(rows)}</table>"
        if rows else "<p>No specific resource could be isolated.</p>"
    )

    def bullet_list(items):
        return "<ul>" + "".join(f"<li>{esc(i)}</li>" for i in items) + "</ul>" if items else "<p>None.</p>"

    evidence = bullet_list([f"{e.get('source')}: {e.get('detail')}" for e in report.get("evidence", [])])
    finops_block = ""
    if audience == "finops":
        untagged = [r for r in resources if r.get("owner_tag_status") != "valid"]
        tag_rows = "".join(
            f"<tr><td {TD}><code>{esc(r.get('resource_id'))}</code></td><td {TD}>{esc(r.get('owner_tag_status'))}</td>"
            f"<td {TD}>{esc(json.dumps(r.get('tags') or {}))}</td></tr>" for r in untagged)
        tagging = (
            f'<h3>Tagging gaps</h3><table style="border-collapse:collapse;width:100%"><tr><th {TH}>Resource</th>'
            f"<th {TH}>Owner tag</th><th {TH}>Tags found</th></tr>{tag_rows}</table>" if untagged else "")
        finops_block = f"<h3>Why this came to FinOps</h3>{bullet_list(reasons)}{tagging}"

    link = anomaly.get("anomalyDetailsLink")
    link_html = f'<p><a href="{esc(link)}">Open the anomaly in the AWS console</a></p>' if link else ""
    subject_scope = resources[0].get("service") if resources else (anomaly.get("rootCauses") or [{}])[0].get("service")
    prefix = "[FinOps review] " if audience == "finops" else ""
    subject = (f"{prefix}AWS cost spike: {subject_scope or 'unknown service'} "
               f"+{usd(impact.get('totalImpact'))} ({report.get('confidence')} confidence)")

    body = f"""<div style="font-family:Segoe UI,Arial,sans-serif;color:#222;max-width:900px">
<h2 style="margin-bottom:4px">AWS cost spike: root cause</h2>
<p style="color:#666;margin-top:0">Anomaly {esc(record.get('anomaly_id'))} &middot; started {esc(anomaly.get('anomalyStartDate'))}
&middot; impact so far {usd(impact.get('totalImpact'))}</p>
<p>{esc(report.get('summary'))}</p>
{finops_block}
<h3>Root cause</h3>
<p>{esc(report.get('root_cause'))}</p>
<p><b>Category:</b> {esc(report.get('cause_category'))} &nbsp; <b>Confidence:</b> {esc(report.get('confidence'))}
 &ndash; {esc(report.get('confidence_rationale'))}</p>
<p><b>Daily cost:</b> {usd(report.get('baseline_daily_usd'))} &rarr; {usd(report.get('spike_daily_usd'))}</p>
<h3>Resources</h3>
{resource_table}
<h3>Recommended actions</h3>
{bullet_list(report.get('recommended_actions', []))}
<h3>Evidence</h3>
{evidence}
<h3>Data gaps</h3>
{bullet_list(report.get('data_gaps', []))}
{link_html}
<p style="color:#888;font-size:12px">Generated automatically by the FinOps cost-spike pipeline using {esc(record.get('model_id'))}.
Reply to {esc(FINOPS_EMAIL)} if this looks wrong.</p>
</div>"""
    return subject, body


# --------------------------------------------------------------------------- #
# Delivery
# --------------------------------------------------------------------------- #
def freshservice_config():
    try:
        enabled = ssm.get_parameter(Name=FS_ENABLED_PARAM)["Parameter"]["Value"].strip().lower() == "true"
    except Exception as err:  # noqa: BLE001
        return {"enabled": False, "error": f"could not read toggle: {err}"}
    if not enabled:
        return {"enabled": False}
    domain = ssm.get_parameter(Name=FS_DOMAIN_PARAM)["Parameter"]["Value"].strip()
    api_key = secrets.get_secret_value(SecretId=FS_SECRET_ID)["SecretString"].strip()
    return {"enabled": True, "domain": domain, "api_key": api_key}


def create_ticket(config, requester, subject, body):
    payload = json.dumps({
        "subject": subject, "description": body, "email": requester,
        "priority": 3, "status": 2, "source": 2,
    }).encode()
    token = base64.b64encode(f"{config['api_key']}:X".encode()).decode()
    request = urllib.request.Request(
        f"https://{config['domain']}/api/v2/tickets", data=payload, method="POST",
        headers={"Content-Type": "application/json", "Authorization": f"Basic {token}"})
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            ticket = json.loads(response.read()).get("ticket", {})
            return {"status": "created", "ticket_id": ticket.get("id")}
    except urllib.error.HTTPError as err:
        return {"status": "failed", "error": f"HTTP {err.code}: {err.read()[:300].decode(errors='replace')}"}
    except Exception as err:  # noqa: BLE001
        return {"status": "failed", "error": str(err)[:300]}


def deliver(anomaly_id, index, audience, to, cc, subject, body, fs_config):
    key = f"notifications/{anomaly_id}/{index:02d}-{audience}.html"
    s3.put_object(Bucket=BUCKET, Key=key, Body=body.encode(), ContentType="text/html; charset=utf-8")
    outcome = {"audience": audience, "to": to, "cc": cc, "subject": subject, "html_key": key}
    try:
        destination = {"ToAddresses": to}
        if cc:
            destination["CcAddresses"] = cc
        message_id = ses.send_email(
            FromEmailAddress=SENDER_EMAIL, Destination=destination,
            Content={"Simple": {"Subject": {"Data": subject}, "Body": {"Html": {"Data": body}}}},
        )["MessageId"]
        outcome["email"] = {"status": "sent", "message_id": message_id}
    except Exception as err:  # noqa: BLE001 - keep the HTML in S3 and report the failure
        outcome["email"] = {"status": "failed", "error": str(err)[:400]}

    if fs_config.get("enabled"):
        outcome["ticket"] = create_ticket(fs_config, to[0], subject, body)
    else:
        outcome["ticket"] = {"status": "disabled", **({"error": fs_config["error"]} if "error" in fs_config else {})}
    return outcome


def handler(event, _context):
    detail = event.get("detail") or {}
    anomaly_id = detail.get("anomalyId", "unknown")
    fs_config = freshservice_config()

    if "failure" in event:
        subject = f"[FinOps review] Cost-spike investigation failed for anomaly {anomaly_id}"
        body = (f"<div style='font-family:Segoe UI,Arial,sans-serif'><h2>Investigation failed</h2>"
                f"<p>The automated root-cause investigation did not complete. The anomaly needs a manual look.</p>"
                f"<pre>{esc(json.dumps(event['failure'], indent=2)[:3000])}</pre>"
                f"<h3>Anomaly</h3><pre>{esc(json.dumps(detail, indent=2)[:4000])}</pre></div>")
        outcomes = [deliver(anomaly_id, 1, "finops-failure", [FINOPS_EMAIL], [], subject, body, fs_config)]
    else:
        record = json.loads(s3.get_object(Bucket=BUCKET, Key=event["report_key"])["Body"].read())
        report = record["report"]
        resources = report.get("resources", [])

        owned = {}
        unowned = []
        for resource in resources:
            if resource.get("owner_tag_status") == "valid":
                owned.setdefault(resource["owner_contact"].lower(), []).append(resource)
            else:
                unowned.append(resource)

        hold_reasons = []
        if SHADOW_MODE:
            hold_reasons.append("Shadow mode is on, so app teams are not contacted directly.")
        if report.get("confidence") != "high":
            hold_reasons.append(f"Confidence is {report.get('confidence')}; app teams are only contacted at high confidence.")
        if report.get("cause_category") == "pricing_term_change":
            hold_reasons.append("The cause is a pricing-term change (Savings Plan or Reserved Instance coverage), "
                                "which FinOps owns rather than an app team.")
        if not resources:
            hold_reasons.append("No specific resource was isolated.")

        outcomes = []
        if hold_reasons:
            if unowned:
                hold_reasons.append(f"{len(unowned)} resource(s) have a missing or invalid owner tag.")
            subject, body = render(record, resources, "finops", hold_reasons)
            outcomes.append(deliver(anomaly_id, 1, "finops", [FINOPS_EMAIL], [], subject, body, fs_config))
        else:
            index = 0
            for owner, owner_resources in sorted(owned.items()):
                index += 1
                subject, body = render(record, owner_resources, "app", [])
                outcomes.append(deliver(anomaly_id, index, "app", [owner], [FINOPS_EMAIL], subject, body, fs_config))
            if unowned:
                index += 1
                reasons = [f"{len(unowned)} resource(s) behind this spike have a missing or invalid owner tag, "
                           "so no app team could be contacted for them."]
                subject, body = render(record, unowned, "finops", reasons)
                outcomes.append(deliver(anomaly_id, index, "finops", [FINOPS_EMAIL], [], subject, body, fs_config))

    summary = {"anomaly_id": anomaly_id, "shadow_mode": SHADOW_MODE, "notifications": outcomes}
    s3.put_object(Bucket=BUCKET, Key=f"notifications/{anomaly_id}/delivery.json",
                  Body=json.dumps(summary, indent=2).encode(), ContentType="application/json")
    return summary
