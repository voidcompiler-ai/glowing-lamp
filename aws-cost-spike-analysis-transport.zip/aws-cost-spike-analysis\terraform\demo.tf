# Sandbox-only resources that give CloudTrail and CloudWatch something real to
# find. Not for production: set deploy_demo_resources = false.

resource "aws_dynamodb_table" "demo_orders" {
  count          = var.deploy_demo_resources ? 1 : 0
  name           = "${var.name_prefix}-demo-orders"
  billing_mode   = "PROVISIONED"
  read_capacity  = 5
  write_capacity = 5
  hash_key       = "pk"

  attribute {
    name = "pk"
    type = "S"
  }

  tags = {
    Owner = var.demo_owner_email
    App   = "orders"
  }

  lifecycle {
    ignore_changes = [read_capacity, write_capacity] # changed by the demo script
  }
}

# Deliberately has no Owner tag, to exercise the tagging-gap route.
resource "aws_dynamodb_table" "demo_sessions" {
  count          = var.deploy_demo_resources ? 1 : 0
  name           = "${var.name_prefix}-demo-sessions"
  billing_mode   = "PROVISIONED"
  read_capacity  = 5
  write_capacity = 5
  hash_key       = "pk"

  attribute {
    name = "pk"
    type = "S"
  }

  tags = {
    App = "sessions"
  }

  lifecycle {
    ignore_changes = [read_capacity, write_capacity]
  }
}
