data "archive_file" "dedupe" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/dedupe"
  output_path = "${path.module}/.build/dedupe.zip"
}

data "archive_file" "agent" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/agent"
  output_path = "${path.module}/.build/agent.zip"
}

data "archive_file" "notify" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/notify"
  output_path = "${path.module}/.build/notify.zip"
}

resource "aws_lambda_function" "dedupe" {
  function_name    = "${var.name_prefix}-dedupe"
  role             = aws_iam_role.dedupe.arn
  runtime          = "python3.13"
  handler          = "handler.handler"
  filename         = data.archive_file.dedupe.output_path
  source_code_hash = data.archive_file.dedupe.output_base64sha256
  timeout          = 10

  environment {
    variables = {
      TABLE_NAME    = aws_dynamodb_table.anomalies.name
      MIN_IMPACT_USD = tostring(var.min_impact_usd)
    }
  }
}

resource "aws_lambda_function" "agent" {
  function_name    = "${var.name_prefix}-agent"
  role             = aws_iam_role.agent.arn
  runtime          = "python3.13"
  handler          = "handler.handler"
  filename         = data.archive_file.agent.output_path
  source_code_hash = data.archive_file.agent.output_base64sha256
  timeout          = var.agent_timeout_seconds
  memory_size      = 512

  environment {
    variables = {
      INVESTIGATION_MODE = var.investigation_mode
      HYBRID_MAX_TURNS   = tostring(var.hybrid_max_turns)
      MODEL_ID         = var.model_id
      BUCKET           = aws_s3_bucket.data.bucket
      ATHENA_WORKGROUP = aws_athena_workgroup.rca.name
      CUR_DATABASE     = aws_glue_catalog_database.cur.name
      CUR_TABLE        = aws_glue_catalog_table.cur.name
      MEMBER_ROLE_NAME = var.member_role_name
      OWNER_TAG_KEYS   = join(",", var.owner_tag_keys)
      CUR_MAX_ATTEMPTS = tostring(var.cur_max_attempts)
    }
  }
}

resource "aws_lambda_function" "notify" {
  function_name    = "${var.name_prefix}-notify"
  role             = aws_iam_role.notify.arn
  runtime          = "python3.13"
  handler          = "handler.handler"
  filename         = data.archive_file.notify.output_path
  source_code_hash = data.archive_file.notify.output_base64sha256
  timeout          = 30

  environment {
    variables = {
      BUCKET                     = aws_s3_bucket.data.bucket
      FINOPS_EMAIL               = var.finops_email
      SENDER_EMAIL               = var.ses_sender_email
      SHADOW_MODE                = tostring(var.shadow_mode)
      FRESHSERVICE_ENABLED_PARAM = aws_ssm_parameter.freshservice_enabled.name
      FRESHSERVICE_DOMAIN_PARAM  = aws_ssm_parameter.freshservice_domain.name
      FRESHSERVICE_SECRET_ID     = aws_secretsmanager_secret.freshservice_api_key.arn
    }
  }
}

locals {
  lambda_retry = [{
    ErrorEquals     = ["Lambda.ServiceException", "Lambda.AWSLambdaException", "Lambda.SdkClientException", "Lambda.TooManyRequestsException"]
    IntervalSeconds = 5
    MaxAttempts     = 3
    BackoffRate     = 2
  }]
}

resource "aws_sfn_state_machine" "rca" {
  name     = var.name_prefix
  role_arn = aws_iam_role.sfn.arn

  definition = jsonencode({
    Comment = "Cost anomaly root-cause investigation"
    StartAt = "Dedupe"
    States = {
      Dedupe = {
        Type       = "Task"
        Resource   = aws_lambda_function.dedupe.arn
        ResultPath = "$.dedupe"
        Retry      = local.lambda_retry
        Next       = "ShouldInvestigate"
      }
      ShouldInvestigate = {
        Type    = "Choice"
        Choices = [{ Variable = "$.dedupe.proceed", BooleanEquals = true, Next = "InitAttempt" }]
        Default = "Skipped"
      }
      Skipped = { Type = "Succeed" }
      InitAttempt = {
        Type       = "Pass"
        Result     = { status = "init", next_attempt = 1 }
        ResultPath = "$.investigation"
        Next       = "Investigate"
      }
      Investigate = {
        Type           = "Task"
        Resource       = aws_lambda_function.agent.arn
        Parameters     = { "detail.$" = "$.detail", "attempt.$" = "$.investigation.next_attempt" }
        ResultPath     = "$.investigation"
        TimeoutSeconds = var.agent_timeout_seconds + 5
        Retry          = local.lambda_retry
        Catch          = [{ ErrorEquals = ["States.ALL"], ResultPath = "$.error", Next = "NotifyFailure" }]
        Next           = "CurReady"
      }
      CurReady = {
        Type    = "Choice"
        Choices = [{ Variable = "$.investigation.status", StringEquals = "cur_not_ready", Next = "WaitForCur" }]
        Default = "Notify"
      }
      WaitForCur = {
        Type    = "Wait"
        Seconds = var.cur_retry_wait_seconds
        Next    = "Investigate"
      }
      Notify = {
        Type       = "Task"
        Resource   = aws_lambda_function.notify.arn
        Parameters = { "detail.$" = "$.detail", "report_key.$" = "$.investigation.report_key" }
        ResultPath = "$.notification"
        Retry      = local.lambda_retry
        End        = true
      }
      NotifyFailure = {
        Type       = "Task"
        Resource   = aws_lambda_function.notify.arn
        Parameters = { "detail.$" = "$.detail", "failure.$" = "$.error" }
        ResultPath = "$.notification"
        Next       = "Failed"
      }
      Failed = { Type = "Fail", Error = "InvestigationFailed" }
    }
  })
}

# Real anomalies arrive with source aws.ce. The second source lets a test
# script inject a simulated anomaly, since aws.* sources cannot be published.
resource "aws_cloudwatch_event_rule" "anomaly" {
  name        = "${var.name_prefix}-anomaly-detected"
  description = "Start a root-cause investigation for each Cost Anomaly Detection anomaly"
  event_pattern = jsonencode({
    source        = ["aws.ce", "finops.simulated.ce"]
    "detail-type" = ["Anomaly Detected"]
  })
}

resource "aws_cloudwatch_event_target" "anomaly" {
  rule     = aws_cloudwatch_event_rule.anomaly.name
  arn      = aws_sfn_state_machine.rca.arn
  role_arn = aws_iam_role.events.arn
}
