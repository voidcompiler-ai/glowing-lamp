variable "aws_profile" {
  description = "AWS CLI profile used to deploy."
  type        = string
  default     = "pluralsight-sandbox"
}

variable "aws_region" {
  description = "Region for the pipeline. Cost Anomaly Detection events are emitted in us-east-1."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  type    = string
  default = "finops-rca"
}

variable "model_id" {
  description = "Bedrock model or inference profile ID for the investigation agent."
  type        = string
  default     = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
}

variable "investigation_mode" {
  description = "agent: Claude drives the investigation tools itself. single_shot: code gathers a fixed evidence checklist and Claude is called once. hybrid: the checklist runs first and Claude follows up with the tools only when the checklist report is not high confidence."
  type        = string
  default     = "agent"
  validation {
    condition     = contains(["agent", "single_shot", "hybrid"], var.investigation_mode)
    error_message = "investigation_mode must be agent, single_shot or hybrid."
  }
}

variable "hybrid_max_turns" {
  description = "Hybrid mode only: the most model calls the agent follow-up may make."
  type        = number
  default     = 10
}

variable "agent_timeout_seconds" {
  description = "Timeout of the investigation Lambda. Agent and hybrid modes need several minutes; single_shot fits in one."
  type        = number
  default     = 900
}

variable "finops_email" {
  description = "FinOps team mailbox. Receives untagged, low-confidence and failed investigations, and is cc'd on app-team mail."
  type        = string
}

variable "ses_sender_email" {
  description = "Verified SES identity used as the From address."
  type        = string
}

variable "owner_tag_keys" {
  description = "Tag keys that may hold the owning team's email address, in order of preference (case-insensitive)."
  type        = list(string)
  default     = ["Owner", "TeamEmail"]
}

variable "shadow_mode" {
  description = "When true, every notification goes to FinOps only. Recommended for the first weeks in production."
  type        = bool
  default     = true
}

variable "min_impact_usd" {
  description = "Anomalies with a total impact below this are not investigated."
  type        = number
  default     = 0
}

variable "cur_retry_wait_seconds" {
  description = "How long to wait before re-checking when the CUR does not yet hold the anomaly day."
  type        = number
  default     = 10800
}

variable "cur_max_attempts" {
  description = "How many times to check for CUR data before investigating with what is there."
  type        = number
  default     = 4
}

variable "member_role_name" {
  description = "Read-only role the agent assumes in the account that owns the anomaly. In production it is deployed to every member account with a StackSet."
  type        = string
  default     = "FinOpsRcaReadOnly"
}

variable "freshservice_enabled" {
  description = "Initial value of the FreshService ticket toggle. Change it later in SSM Parameter Store without redeploying."
  type        = bool
  default     = false
}

variable "freshservice_domain" {
  description = "FreshService domain, e.g. yourcompany.freshservice.com."
  type        = string
  default     = "example.freshservice.com"
}

variable "deploy_demo_resources" {
  description = "Create two small DynamoDB tables used to demonstrate the pipeline in a sandbox."
  type        = bool
  default     = false
}

variable "demo_owner_email" {
  description = "Value of the Owner tag on the tagged demo table."
  type        = string
  default     = "orders-team@example.com"
}
