# Pluralsight sandbox settings.
aws_profile = "pluralsight-sandbox1"
aws_region  = "us-east-1"

# The sandbox caps Bedrock at 20,000 tokens and shuts down on long Lambda
# timeouts, so the full agent cannot run here.
# Sonnet 4.5 worked for one run in this sandbox and was then refused with a
# Marketplace subscription error; Haiku 4.5 kept working.
model_id              = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
investigation_mode    = "single_shot"
agent_timeout_seconds = 60

# Placeholders. SES is in sandbox mode, so mail is only delivered once these
# are replaced with addresses verified in SES. Until then the rendered email is
# still saved to S3 under notifications/.
finops_email     = "finops@example.com"
ses_sender_email = "finops@example.com"
demo_owner_email = "orders-team@example.com"

shadow_mode            = false # so the app-team route can be demonstrated
min_impact_usd         = 0
cur_retry_wait_seconds = 30
deploy_demo_resources  = true
