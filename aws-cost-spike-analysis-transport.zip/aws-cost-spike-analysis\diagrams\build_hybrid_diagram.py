"""Generate the hand-positioned, animated diagram of hybrid investigation mode.

Reuses the drawing code in build_mcp_diagram.py and swaps in this diagram's boxes and arrows.
Each box shows the AWS service or step (bold), the resource (monospace) and its purpose (italic).
Each arrow is labelled with the data that travels along it.
"""
import re
import sys

import build_mcp_diagram as b

b.W, b.H = 2350, 1230
b.NODE_H = 84
b.STYLE["secure"] = ("#FFD6D6", "#A32D2D", "#501313")

# id: (x, y, width, style, service, resource name, purpose)
b.NODES = {
    "cad": (40, 120, 250, "trigger", "💰 AWS Cost Anomaly Detection", "management account", "spots the unusual spend"),
    "eb": (450, 120, 240, "trigger", "📡 Amazon EventBridge rule", "finops-rca-anomaly-detected", "starts the workflow"),
    "sfn": (820, 120, 230, "trigger", "🔄 AWS Step Functions", "finops-rca", "runs the steps in order"),
    "dedupe": (1200, 120, 250, "compute", "⚡ AWS Lambda", "finops-rca-dedupe", "skips anomalies already handled"),
    "ddb": (1600, 120, 230, "data", "🗃️ Amazon DynamoDB", "finops-rca-anomalies", "remembers anomalies seen"),
    "stageA": (810, 330, 260, "compute", "📋 Stage A · fixed checklist", "finops-rca-agent (Lambda)",
               "always gathers the same evidence"),
    "decide": (810, 500, 260, "mcp", "❓ First report high confidence?", "check in the Lambda code",
               "decides whether to dig deeper"),
    "stageB": (810, 670, 260, "mcp", "🤖 Stage B · agent follow-up", "same Lambda, max 10 model calls",
               "Claude picks the extra checks"),
    "bedrock": (1250, 470, 250, "compute", "🧠 Amazon Bedrock", "Claude, Converse API",
                "writes reports, steers follow-up"),
    "tools": (1640, 460, 260, "compute", "🧰 Read-only tools", "five functions in the Lambda",
              "the only route to AWS data"),
    "athena": (2060, 260, 250, "data", "🔎 Amazon Athena + Glue", "CUR 2.0 table", "what grew, down to resource ID"),
    "ct": (2060, 360, 250, "email", "📝 AWS CloudTrail", "event history", "who changed what, and when"),
    "cw": (2060, 460, 250, "email", "📈 Amazon CloudWatch", "metrics", "whether usage really grew"),
    "cfg": (2060, 560, 250, "email", "⚙️ AWS Config", "configuration history", "settings before and after"),
    "tag": (2060, 660, 250, "email", "🏷️ Resource Groups Tagging API", "live tags", "who owns the resource"),
    "s3rep": (380, 500, 230, "data", "📦 Amazon S3", "reports/", "keeps every root-cause report"),
    "notify": (105, 940, 250, "compute", "📨 AWS Lambda", "finops-rca-notify", "picks who to tell, builds email"),
    "fs": (560, 830, 220, "opt", "🎫 FreshService", "toggle off by default", "optional ITSM ticket"),
    "ses": (560, 940, 220, "email", "✉️ Amazon SES", "email identity", "delivers the email"),
    "ssm": (30, 1090, 230, "secure", "🎚️ SSM Parameter Store", "/finops-rca/freshservice/*", "ticket on/off switch, domain"),
    "sec": (275, 1090, 230, "secure", "🔐 AWS Secrets Manager", "finops-rca/freshservice-api-key", "holds the FreshService key"),
    "s3not": (560, 1090, 230, "data", "📦 Amazon S3", "notifications/", "copy of each email sent"),
    "app": (1040, 890, 250, "people", "👥 App team", "from the Owner tag", "gets tagged, high-confidence spikes"),
    "fin": (1040, 990, 250, "people", "👤 FinOps team", "FinOps mailbox", "gets untagged or uncertain ones"),
}

# (x, y, width, height, title)
b.GROUPS = [
    (24, 80, 682, 144, "1 · Trigger"),
    (804, 80, 1042, 144, "2 · Orchestration"),
    (794, 290, 292, 480, "3 · Investigation"),
    (2044, 220, 282, 540, "Evidence sources · read-only"),
    (24, 790, 782, 404, "4 · Notification"),
]

side, line, hcurve, poly = b.side, b.line, b.hcurve, b.poly

# (path, kind, label, label_x, first_line_y, anchor)
b.EDGES = [
    (line(side("cad", "r"), side("eb", "l")), "flow",
     "1 · anomaly event:\naccount, service,\nusage type, $ impact", 370, 122, "middle"),
    (line(side("eb", "r"), side("sfn", "l")), "flow", "2 · same event,\nunchanged", 755, 138, "middle"),
    (line(side("sfn", "r"), side("dedupe", "l")), "flow", "3 · the event;\nreturns proceed\nor skip", 1125, 122, "middle"),
    (line(side("dedupe", "r"), side("ddb", "l")), "flow", "anomaly ID,\nimpact, run count", 1525, 138, "middle"),
    (line(side("sfn", "b", 60), side("stageA", "t", 55)), "flow", "4 · anomaly details,\nattempt number", 1007, 252, "start"),
    (poly(side("stageA", "r", -22), (1710, 350), side("tools", "t", -60)), "flow",
     "5 · fixed lookups: six CUR queries, then top resources, their parent groups, recent changes", 1390, 338, "middle"),
    (hcurve(side("stageA", "r", 22), side("bedrock", "l", -20)), "flow",
     "6 · checklist evidence;\nreturns first report", 1185, 412, "start"),
    (line(side("stageA", "b"), side("decide", "t")), "flow", "7 · first report\n+ its confidence", 952, 452, "start"),
    (line(side("decide", "l"), side("s3rep", "r")), "flow", "if high: first report\nis the final report", 710, 514, "middle"),
    (line(side("decide", "b"), side("stageB", "t")), "flow",
     "8 · if not high:\nevidence, first\nreport, named gaps", 952, 610, "start"),
    (hcurve(side("stageB", "r", -22), side("bedrock", "l", 20)), "flow",
     "9 · evidence so far;\nreturns next tool call\nor final report", 1195, 610, "start"),
    (poly(side("stageB", "r", 22), (1710, 734), side("tools", "b", -60)), "flow",
     "10 · the tool call Claude chose (SQL, event name, metric); returns the result", 1390, 722, "middle"),
    (hcurve(side("tools", "r"), side("athena", "l")), "flow",
     "read-only AWS calls: SQL\nto Athena; the rest via\nIAM role FinOpsRcaReadOnly", 1960, 366, "end"),
    (hcurve(side("tools", "r"), side("ct", "l")), "flow", "", 0, 0, "middle"),
    (line(side("tools", "r"), side("cw", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("tools", "r"), side("cfg", "l")), "flow", "", 0, 0, "middle"),
    (hcurve(side("tools", "r"), side("tag", "l")), "flow", "", 0, 0, "middle"),
    (poly(side("stageB", "l"), (495, 712), side("s3rep", "b")), "flow",
     "11 · final report\n(replaces the first)", 655, 686, "middle"),
    (poly(side("sfn", "b", -65), (870, 262), (170, 262), side("notify", "t", -60)), "flow",
     "12 · anomaly details + S3 location of the report", 520, 252, "middle"),
    (poly(side("s3rep", "l"), (290, 542), side("notify", "t", 60)), "flow", "full report (JSON)", 302, 700, "start"),
    (line(side("notify", "r"), side("ses", "l")), "flow", "13 · from, to, subject,\nHTML body", 457, 958, "middle"),
    (poly(side("notify", "t", 100), (330, 872), side("fs", "l")), "opt",
     "ticket: subject, description,\nrequester", 445, 848, "middle"),
    (line((150, 1024), (145, 1090)), "flow", "reads toggle,\ndomain, API key", 138, 1052, "end"),
    (line((240, 1024), (390, 1090)), "flow", "", 0, 0, "middle"),
    (line((330, 1024), (675, 1090)), "flow", "copy of email +\ndelivery record", 580, 1046, "start"),
    (hcurve(side("ses", "r"), side("app", "l")), "flow",
     "the email, when owner is\nknown and confidence high", 910, 902, "middle"),
    (hcurve(side("ses", "r"), side("fin", "l")), "flow", "the email, in all\nother cases", 910, 1050, "middle"),
]

b.LEGEND = [
    ("mcp", "New in hybrid mode"),
    ("trigger", "Trigger and orchestration"),
    ("compute", "Compute and model"),
    ("data", "Data stores"),
    ("secure", "Settings and secrets"),
    ("email", "AWS services read or called"),
    ("people", "People"),
    ("opt", "Optional"),
]

TITLE = "FinOps cost-spike pipeline: hybrid investigation mode"
SUB = ("Built and tested locally with stubbed AWS calls; not yet run in an AWS account. Stage A always runs the same "
       "checklist and Claude writes a first report. If that report is high confidence it is final. If not, Stage B "
       "gives Claude the same read-only tools to follow up on the named gaps, and its report replaces the first. If "
       "Stage B fails or the Lambda is nearly out of time, the first report is kept and the reason is listed in it. "
       "Stages A and B and the tools all run inside one Lambda, finops-rca-agent. Each arrow is labelled with the "
       "data it carries, and the numbers 1 to 13 give the order; steps 8 to 11 happen only when the first report is "
       "not high confidence.")
DESC = ("A cost anomaly flows through EventBridge and Step Functions to a dedupe Lambda and then the investigation "
        "Lambda. Stage A gathers a fixed checklist of evidence through read-only tools and asks Claude on Bedrock "
        "for a first report. A check in code sends a high-confidence report straight to S3. Otherwise Stage B lets "
        "Claude choose further tool calls and write a final report. The tools read Athena, CloudTrail, CloudWatch, "
        "Config and tags. The notify Lambda emails the app team or FinOps through SES.")


def build():
    page = b.build()
    page = page.replace("FinOps cost-spike pipeline: target architecture with open-source MCP servers", TITLE)
    page = page.replace("Target architecture with open-source MCP servers", "Hybrid investigation mode")
    page = re.sub(r'<p class="sub">.*?</p>', f'<p class="sub">{SUB}</p>', page, flags=re.S)
    page = re.sub(r'<desc id="d">.*?</desc>', f'<desc id="d">{DESC}</desc>', page, flags=re.S)
    return page


if __name__ == "__main__":
    with open(sys.argv[1], "w", encoding="utf-8") as handle:
        handle.write(build())
    print("written", sys.argv[1])
