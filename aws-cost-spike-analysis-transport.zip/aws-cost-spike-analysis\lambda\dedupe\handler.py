"""Dedupe and noise-floor gate for Cost Anomaly Detection events.

AWS re-emits the same anomaly as it develops. An anomaly is investigated the
first time it is seen, and again only if its impact has grown materially.
"""
import os
import time
from decimal import Decimal

import boto3

TABLE = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
MIN_IMPACT_USD = float(os.environ.get("MIN_IMPACT_USD", "0"))
REINVESTIGATE_GROWTH = float(os.environ.get("REINVESTIGATE_GROWTH", "0.5"))
TTL_DAYS = 90


def handler(event, _context):
    detail = event.get("detail") or {}
    anomaly_id = detail.get("anomalyId")
    if not anomaly_id:
        raise ValueError("event has no detail.anomalyId")

    impact = float((detail.get("impact") or {}).get("totalImpact") or 0)
    if impact < MIN_IMPACT_USD:
        return {
            "proceed": False,
            "reason": f"impact ${impact:.2f} is below the ${MIN_IMPACT_USD:.2f} noise floor",
        }

    item = TABLE.get_item(Key={"anomaly_id": anomaly_id}).get("Item")
    runs = 0
    if item:
        runs = int(item.get("runs", 0))
        last = float(item.get("last_impact", 0))
        if impact <= last * (1 + REINVESTIGATE_GROWTH):
            return {
                "proceed": False,
                "reason": f"already investigated at ${last:.2f}; impact has not grown by "
                f"{REINVESTIGATE_GROWTH:.0%}",
            }

    now = int(time.time())
    TABLE.put_item(
        Item={
            "anomaly_id": anomaly_id,
            "last_impact": Decimal(str(round(impact, 4))),
            "runs": runs + 1,
            "updated_at": now,
            "expires_at": now + TTL_DAYS * 86400,
        }
    )
    return {
        "proceed": True,
        "reason": "new anomaly" if runs == 0 else "impact grew since last investigation",
        "run": runs + 1,
    }
