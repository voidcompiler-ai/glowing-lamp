# AWS cost-spike root-cause pipeline

Cost Anomaly Detection event -> EventBridge -> Step Functions -> Claude agent on Bedrock
(CUR 2.0 in Athena, CloudTrail, Config, CloudWatch, tags) -> report in S3 -> email (SES) and
optional FreshService ticket to the owning team, or to FinOps.

## Layout

- `cloudformation/` - infrastructure for the enterprise Organization; see its README. Not yet deployed.
- `terraform/` - infrastructure for a sandbox. `demo.tf` is sandbox-only.
- `lambda/dedupe` - skips anomalies already investigated or below the noise floor.
- `lambda/agent` - the investigation agent and its read-only tools.
- `lambda/notify` - routing, email rendering, SES, FreshService.
- `scripts/demo.py` - loads synthetic CUR data and fires simulated anomalies.
- `out/` - reports and rendered emails downloaded by the demo script.

## Deploy to a fresh sandbox

A new Pluralsight sandbox is a new account, so delete the old state first.

```bash
aws configure --profile pluralsight-sandbox1
```

Set `aws_profile` in `terraform/terraform.tfvars` to the profile name you used.

```bash
rm terraform/terraform.tfstate terraform/terraform.tfstate.backup terraform/tfplan
```

```bash
terraform -chdir=terraform init
```

```bash
terraform -chdir=terraform apply
```

```bash
py scripts/demo.py load-cur
```

```bash
py scripts/demo.py change
```

Wait about five minutes for CloudTrail to record the changes, then:

```bash
py scripts/demo.py fire orders
```

Other scenarios: `sessions` (table with no owner tag) and `savingsplan` (Savings Plan expiry).
`py scripts/demo.py revert` puts the demo tables back to 5 capacity units.

## Investigation modes

- `agent` (default, for production): Claude drives the read-only tools itself over many model
  calls. Thorough, but needs a Lambda timeout of several minutes and tens of thousands of tokens.
- `single_shot` (for the sandbox): code runs a fixed evidence checklist (six CUR queries, then
  CloudTrail, CloudWatch, Config and tags for the top three resources and their parent groups)
  and Claude is called once to interpret it. The three sandbox runs used about 5,000 tokens and
  10 to 40 seconds each; that was before the rules below were added, so expect more of both.
- `hybrid` (recommended for production once measured): the `single_shot` checklist runs first. If
  its report is high confidence, that is the result. Otherwise Claude gets the same read-only tools
  as `agent` mode, starts from the checklist evidence and the first report, and follows up on the
  named gaps for at most `hybrid_max_turns` model calls (default 10). If the follow-up fails or
  there are fewer than 90 seconds left before the Lambda timeout, the checklist report is kept and
  the reason is listed in its data gaps. The saved report records what ran under `hybrid_stages`.
  Set `agent_timeout_seconds` to 300 or more.

### What the checklist looks at

The checklist is rule-driven code in `lambda/agent/handler.py`. Each rule exists for a kind of
cost increase. Only the first two CUR queries are required; every other rule fails soft, so an
error becomes a data gap in the report and not a failed investigation.

| Rule | Evidence it adds | Kinds of increase it is for |
|---|---|---|
| Cost breakdown by line item type | `cost_breakdown` | Savings Plan or RI expiry, free tier used up, Spot replaced by On-Demand, credits or discounts ending, fees, tax, Marketplace, a move between usage types |
| Daily trend over 35 days | `daily_trend` | Lasting step, one-off job, organic growth, spike already over, weekly or monthly recurring charge, many new resources |
| Breakdown by operation and region | `usage_type_detail` | Data transfer with no resource ID, S3 request types and storage classes |
| Regions that are new or grew | `region_breakdown` | Unplanned rollout, resources created with leaked credentials |
| Resource ranking | `top_resources` | A single resource resized, created or busier |
| Roll-up by parent | `resource_groups` | Auto Scaling instances, ECS tasks, EMR or EKS nodes, CloudFormation stacks, including members already terminated |
| Write events by event and principal | `change_summary` | A burst of creations with no single costly resource (snapshots, volumes, instances) |
| Metrics chosen by resource type | `resource_evidence` | Traffic through NAT gateways, load balancers, transit gateways, CloudFront; log ingestion; S3, EFS and Aurora storage and I/O; requests to Lambda, SQS, SNS, Kinesis, Bedrock, Step Functions |

The rules were tested with stubbed AWS calls only. The SQL for the four added queries has not
run on Athena, and the tag keys and resource ID formats they rely on have not been checked
against a real CUR. Known gaps: which workload sent traffic through a shared gateway (needs VPC
Flow Logs), why an Auto Scaling group scaled when an alarm triggered it, services whose line
items carry neither a resource ID nor a useful operation, and shared costs that are split by
allocation rules outside the CUR.

The Pluralsight sandbox caps Bedrock at 20,000 tokens per session and shuts the sandbox down if a
Lambda timeout is set too high (900 s triggered it; 60 s did not), so only `single_shot` fits there.
That is about three investigations per sandbox.

## Settings

Set in `terraform/terraform.tfvars`: `aws_profile`, `investigation_mode`, `hybrid_max_turns`, `agent_timeout_seconds`,
`finops_email`, `ses_sender_email`, `shadow_mode`, `min_impact_usd`, `owner_tag_keys`, `model_id`,
`cur_retry_wait_seconds`.

The FreshService toggle is the SSM parameter `/finops-rca/freshservice/enabled` (`true` or
`false`), read on every run. The API key goes in the Secrets Manager secret
`finops-rca/freshservice-api-key`, and the domain in `freshservice_domain`.

## Sandbox substitutions

- The CUR is synthetic JSON, not the real Parquet export. Column names and the
  `billing_period` partition match CUR 2.0.
- Anomalies are simulated events with source `finops.simulated.ce`; real ones arrive as `aws.ce`.
- The member-account read role is in the same account. In production it goes to every member
  account with a CloudFormation StackSet.
- AWS Config is not recording in the sandbox, so the agent falls back to CloudTrail.
