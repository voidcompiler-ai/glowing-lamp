output "account_id" {
  value = local.account_id
}

output "region" {
  value = var.aws_region
}

output "aws_profile" {
  value = var.aws_profile
}

output "bucket" {
  value = aws_s3_bucket.data.bucket
}

output "state_machine_arn" {
  value = aws_sfn_state_machine.rca.arn
}

output "cur_database" {
  value = aws_glue_catalog_database.cur.name
}

output "cur_table" {
  value = aws_glue_catalog_table.cur.name
}

output "demo_orders_table_arn" {
  value = one(aws_dynamodb_table.demo_orders[*].arn)
}

output "demo_sessions_table_arn" {
  value = one(aws_dynamodb_table.demo_sessions[*].arn)
}

output "demo_owner_email" {
  value = var.demo_owner_email
}

output "freshservice_toggle_parameter" {
  value = aws_ssm_parameter.freshservice_enabled.name
}
