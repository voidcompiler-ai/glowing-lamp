# Handoff: AWS cost-spike root-cause pipeline

This document hands the project to another Claude session (Claude Enterprise, Opus 5.5) and to
the engineer working with it. It is meant to travel **with the code in this folder**, not to
replace it. Read section 1 first.

## 1. If you are the Claude session picking this up

- **Use the code in this folder. Do not rebuild it from this description.** The code contains
  fixes that were found by running it against AWS, and a rebuild would lose them.
- **Nothing here has run in the enterprise Organization.** It ran in two Pluralsight sandbox
  accounts, both now expired. Section 7 says exactly what was and was not tested.
- **The user's working rule: design before code.** Propose and get an explicit yes before
  building or deploying anything. Never deploy to the Organization without their go-ahead.
- **Credentials:** the user configures AWS CLI profiles themself. Do not ask for access keys in
  chat. Use the profile name they give you.
- **Next piece of work:** section 9 (changes needed to run in the Organization). None of it
  has been started.
- **Before changing the investigation Lambda, run the local tests** (section 6). They need no
  AWS access.

## 2. What the user asked for

The user is an AWS CloudOps/FinOps engineer for an enterprise AWS Organization:

- About 65 accounts, with billing on the management account.
- CUR 2.0 data export with resource IDs.
- AWS Cost Anomaly Detection, which emails only the high-level cost type.
- All resources are expected to be tagged with an owner.
- CloudHealth with an MCP server, Claude Enterprise and Claude Code are available. AWS
  open-source MCP servers are allowed.

The request: when a cost spike is detected, automatically find the root cause down to the
resource ID, notify the owning app team with full detail, and report untagged resources to
FinOps.

Decisions the user made during design:

| Topic | Decision |
|---|---|
| Model runtime | Amazon Bedrock |
| Notifications | Email through SES, plus a FreshService ticket that can be switched on or off |
| Owner lookup | A resource tag holds the contact email |
| Evidence | CUR, CloudTrail, AWS Config and CloudWatch |
| Savings Plan and RI check | Yes |
| Who is emailed | The app team directly only when confidence is high; otherwise FinOps |
| Infrastructure as code | Terraform |
| Lags | Detection lag, CUR lag and line items without resource IDs are all acceptable |

## 3. How it works

One anomaly flows through these steps:

1. **Detect.** Cost Anomaly Detection emits an event (`source: aws.ce`,
   `detail-type: Anomaly Detected`) with the account, service, usage type and dollar impact.
2. **Trigger.** An EventBridge rule starts the Step Functions state machine `finops-rca`.
3. **Filter.** The dedupe Lambda drops anomalies below a minimum impact, and ones already
   investigated unless the impact has grown by more than 50%. State is kept in DynamoDB with a
   90-day expiry.
4. **Wait for billing data.** The investigation Lambda checks that the CUR holds data for the
   spike's first day. If not, the state machine waits and retries, then carries on and records
   the gap.
5. **Investigate.** The investigation Lambda produces a root-cause report. Section 4 describes
   the three modes.
6. **Checks in code.** The Lambda looks up the owner tag itself (live tags first, then the tags
   recorded in the CUR). It lowers a high confidence to medium if the member account or the CUR
   could not be read. It saves the report to S3.
7. **Route.** The notify Lambda emails the app team (FinOps copied) only when confidence is
   high, the owner tag is a valid email address, the cause is not a pricing-term change, and
   shadow mode is off. Everything else goes to FinOps with the reason.
8. **Deliver.** Email goes through SES and a copy is saved to S3. A FreshService ticket is
   raised if the toggle is on.
9. **Failure.** Any failed step sends FinOps an email saying the investigation failed.

Design points worth keeping:

- **Routing and owner lookup are plain code, never the model.** Tag values and resource names
  are untrusted text, so nothing in them can steer who gets notified.
- **All AWS access is by direct API call (boto3) with IAM roles.** There are no API keys for
  AWS and no MCP servers in what was built.
- **Member-account evidence is read through one read-only role**, `FinOpsRcaReadOnly`, assumed
  by the investigation Lambda.
- **"Agent" is a pattern, not an AWS service:** a loop in the Lambda where Claude picks the next
  read-only tool call and the code runs it. Bedrock Agents and AgentCore are not used.

## 4. Investigation modes

Set by `investigation_mode` in `terraform/terraform.tfvars`.

| Mode | What happens | Status |
|---|---|---|
| `single_shot` | Code runs a fixed checklist of evidence, then Claude is called once to write the report | Ran in the sandbox (before the checklist was widened) |
| `agent` | Claude drives five read-only tools itself over many calls | Ran in the first sandbox, two scenarios |
| `hybrid` | The checklist runs first (Stage A). If its report is not high confidence, Claude follows up with the tools (Stage B) and its report replaces the first | Local tests only |

"Hybrid" means checklist plus agent. It does not mean MCP plus API.

**Stage A checklist rules** (all in `lambda/agent/handler.py`, in the section headed
"Single-shot mode"). Only the first and fifth are required; the rest fail soft and become data
gaps in the report.

| Rule | Evidence key | Kinds of increase it is for |
|---|---|---|
| Cost breakdown by line item type | `cost_breakdown` | Savings Plan or RI expiry, free tier used up, Spot replaced by On-Demand, credits or discounts ending, fees, tax, Marketplace, a move between usage types |
| Daily trend over 35 days | `daily_trend` | Lasting step, one-off job, organic growth, spike already over, weekly or monthly recurring charge, many new resources |
| Breakdown by operation and region | `usage_type_detail` | Data transfer with no resource ID, S3 request types and storage classes |
| Regions that are new or grew | `region_breakdown` | Unplanned rollout, resources created with leaked credentials |
| Resource ranking | `top_resources` | A single resource resized, created or busier |
| Roll-up by parent | `resource_groups` | Auto Scaling instances, ECS tasks, EMR or EKS nodes, CloudFormation stacks, including members already terminated |
| Write events by event and principal | `change_summary` | A burst of creations with no single costly resource |
| Metrics chosen by resource type | `resource_evidence` | Traffic through NAT gateways, load balancers, transit gateways, CloudFront; log ingestion; S3, EFS and Aurora storage and I/O; requests to Lambda, SQS, SNS, Kinesis, Bedrock, Step Functions |

**Stage B** runs for at most `hybrid_max_turns` model calls (default 10). If it fails, or fewer
than 90 seconds remain before the Lambda timeout, the Stage A report is kept and the reason is
added to its data gaps. The saved report records what ran under `hybrid_stages`.

**The five read-only tools** (used by `agent` mode and Stage B):

| Tool | AWS API | Returns |
|---|---|---|
| `query_cur` | Athena | CUR rows; one `SELECT` only, 60 rows at most |
| `lookup_cloudtrail` | CloudTrail `LookupEvents` | Write events: who changed what, when |
| `get_config_history` | AWS Config | Configuration history of a resource |
| `get_metric` | CloudWatch `GetMetricStatistics` | Usage metrics |
| `get_resource_tags` | Resource Groups Tagging API | Live tags |

## 5. What is in this folder

| Path | Contents |
|---|---|
| `lambda/dedupe/handler.py` | Minimum-impact filter and dedupe |
| `lambda/agent/handler.py` | The investigation: tools, all three modes, Stage A rules, owner lookup |
| `lambda/notify/handler.py` | Routing, email rendering, SES, FreshService |
| `cloudformation/` | Infrastructure for the Organization, with its own README and deploy steps. Not yet deployed or linted |
| `terraform/` | Infrastructure for a sandbox only. `demo.tf` creates the demo tables |
| `terraform/terraform.tfvars` | Sandbox settings (Haiku 4.5, `single_shot`, 60-second timeout) |
| `scripts/demo.py` | Loads synthetic CUR data and fires simulated anomalies; sandbox only |
| `tests/` | Local tests with every AWS and model call stubbed |
| `diagrams/` | Three diagrams as HTML (animated), PNG and JPEG, plus their Python generators |
| `README.md` | Deploy steps for a sandbox, modes, settings |
| `PREREQUISITES.md` | What must already exist in AWS before deploying to the Organization, and how to map the existing CUR 2.0 export |

The three diagrams:

- `finops_rca_architecture.*`: what was deployed in the sandbox (`single_shot`).
- `finops_rca_hybrid_architecture.*`: hybrid mode as coded. Not deployed.
- `finops_rca_mcp_architecture.*`: a proposed design using Bedrock AgentCore and open-source
  AWS MCP servers. Never built, and the server list is unconfirmed.

Do **not** carry these across; they are local to this PC or belong to dead sandboxes:

- `terraform/terraform.tfstate` and `terraform.tfstate.backup` (state of an expired sandbox)
- `terraform/local.auto.tfvars` (holds a personal email address)
- `terraform/.terraform/`, `terraform/.build/`, `out/`, `__pycache__/`

## 6. Running the local tests

They need Python and boto3, but no AWS access and no model tokens.

```bash
py tests/test_hybrid.py lambda/agent
```

```bash
py tests/test_stage_a_rules.py lambda/agent
```

Both should end with `all checks passed`. They prove the control flow and the shape of the
evidence. They do not prove that the SQL is valid Athena SQL or that Claude reads the evidence
correctly.

## 7. What was tested, and what was not

**Ran end to end in a sandbox** (`single_shot`, Haiku 4.5, synthetic CUR data, simulated event):

| Scenario | Result |
|---|---|
| Tagged DynamoDB table with raised capacity | Correct cause; emailed the tagged owner with FinOps copied |
| Untagged DynamoDB table with raised capacity | Correct cause; sent to FinOps as a tagging gap |
| Savings Plan expiry | Correct cause, classed as a pricing-term change; sent to FinOps |

Also verified there: the failure-path email, the dedupe gate, owner lookup from CUR tags, and
one real SES delivery (it landed in spam because the sender was a personal address).

**Ran end to end in a third sandbox, deployed from the CloudFormation templates** (`hybrid`
mode, Haiku 4.5, 60-second timeout, widened Stage A):

| Scenario | Result |
|---|---|
| Tagged DynamoDB table with raised capacity | Correct cause; 17 s, 8,052 tokens; routed to the owner |
| Auto Scaling group growing from 2 to 12 instances | Correct group and size; 19 s, 8,702 tokens; routed to the owner, but with unjustified high confidence (fixed in code afterwards) |

Also verified there: `pipeline.yaml` and `member-role.yaml` deploy cleanly; all six Stage A
queries run on Athena; the parent roll-up and the no-resource-ID breakdown return the right rows
(checked without the model); the role assumption from the investigation role to the member
role; and the SES permission (SES refused the placeholder addresses as unverified, which means
the IAM check passed).

**Tested only with stubbed calls:** the Stage B follow-up, the confidence cap for uncorroborated
causes, and the minimum-increase threshold. The last two were added after the sandbox runs and
verified against Athena or locally, but not re-run with the model.

**Never tested:**

- A real Cost Anomaly Detection event. The simulated one was built from documentation.
- A real CUR 2.0 export. The sandbox table was JSON files generated by `scripts/demo.py`.
- The tag keys and resource ID formats the Stage A rules match on, against a real CUR. They
  work on the synthetic data, which I wrote to match my own assumptions.
- `event-forwarder.yaml`, the StackSet rollout and the Organization ID condition.
- FreshService ticketing, and the CUR wait-and-retry loop.
- AWS Config evidence (no recorder in the sandbox) and most CloudWatch evidence (the demo
  resources were minutes old).
- Cross-account access. The read-only role was in the same account as the pipeline.
- Token use and run time since Stage A was widened. The earlier runs used about 5,000 tokens.

## 8. Lessons from the sandbox that are already in the code

- **CUR tags:** `CAST(map AS varchar)` fails in Athena. The code uses
  `json_format(CAST(resource_tags AS json))`.
- **Scope:** the resource ranking is limited to the anomaly's usage type, because an unrelated
  spike in the same account was once mixed into a report.
- **Output limit:** the single model call uses `maxTokens` 3000 and raises an error if the
  report is cut off, instead of saving a truncated one.
- **Pluralsight sandbox limits** (not relevant to the Organization): a 900-second Lambda timeout
  shut the sandbox down; Bedrock is capped at 20,000 tokens; AgentCore, Bedrock Agents, Cost
  Explorer and Organizations are blocked.

## 9. Changes needed to run in the Organization

The Organization uses CloudFormation, not Terraform. The templates in `cloudformation/` were
written for it and already contain the infrastructure changes below. They pass `cfn-lint` and
were deployed once to a single sandbox account; they have not been deployed to the
Organization. Start with `cloudformation/README.md`.

**Infrastructure changes, as made in the CloudFormation templates:**

| Area | Sandbox (Terraform) | Organization (CloudFormation) |
|---|---|---|
| Billing data | Glue table over synthetic files | Reads the existing CUR 2.0 table, bucket and optional KMS key, given as parameters |
| Member accounts | Read-only role in one account | `member-role.yaml` for a StackSet; trust limited to the investigation role |
| Trigger | Rule also accepts the simulated source `finops.simulated.ce` | Real `aws.ce` events only; replay by starting the state machine directly |
| Demo resources | Two demo tables | None |
| Model and mode | Haiku 4.5, `single_shot`, 60 seconds | `ModelId` is required with no default; `hybrid`, 600 seconds |
| CUR wait | 30 seconds | 10800 seconds by default |
| Account choice | Single account | `event-forwarder.yaml` lets the pipeline run outside the management account |

**Decisions and actions for the user and their teams:**

- Which account runs the pipeline: the management account, where the events arrive, or a FinOps
  tooling account with events forwarded to it.
- Security review of the cross-account role and of sending billing and CloudTrail data to
  Claude on Bedrock.
- Bedrock model access for the chosen model.
- SES production access and a verified sending domain.
- The tag keys that hold the owner contact (`owner_tag_keys`), activated as cost allocation tags.
- FreshService domain and API key, and whether to turn the toggle on.

**Suggested rollout:**

1. Deploy with `shadow_mode = true`, so every report goes to FinOps only.
2. Create the read-only role in two or three pilot accounts first.
3. Replay 20 to 30 past anomalies with known causes and score the reports. This is also the
   only way to compare the three modes; no such comparison has been done.
4. Fix what that shows, extend to all accounts, then turn shadow mode off.

## 10. Known gaps in the design

- Which workload sent traffic through a shared NAT gateway or load balancer. That needs VPC
  Flow Logs, which nothing reads.
- Why an Auto Scaling group scaled when an alarm or schedule triggered it. That is in the
  group's activity history, which no tool reads.
- Services whose billing lines carry neither a resource ID nor a useful operation.
- Shared costs split by allocation rules outside the CUR, such as CloudHealth reallocation.
- The owner tag on a shared resource may name the platform team, not the team that caused the
  cost.

## 11. Settings

In `terraform/terraform.tfvars`: `aws_profile`, `aws_region`, `model_id`, `investigation_mode`,
`hybrid_max_turns`, `agent_timeout_seconds`, `finops_email`, `ses_sender_email`,
`owner_tag_keys`, `shadow_mode`, `min_impact_usd`, `cur_retry_wait_seconds`, `cur_max_attempts`,
`member_role_name`, `freshservice_enabled`, `freshservice_domain`, `deploy_demo_resources`.

The FreshService toggle is the SSM parameter `/finops-rca/freshservice/enabled`, read on every
run. The API key is the Secrets Manager secret `finops-rca/freshservice-api-key`.
