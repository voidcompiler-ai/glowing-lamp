"""Local test of hybrid mode with every AWS call stubbed. No AWS access, no tokens."""
import json
import os
import sys

os.environ.update(MODEL_ID="stub", BUCKET="b", ATHENA_WORKGROUP="w", CUR_DATABASE="d", CUR_TABLE="cur2",
                  MEMBER_ROLE_NAME="r", INVESTIGATION_MODE="hybrid", AWS_DEFAULT_REGION="us-east-1",
                  AWS_ACCESS_KEY_ID="x", AWS_SECRET_ACCESS_KEY="x", AWS_EC2_METADATA_DISABLED="true")
sys.path.insert(0, sys.argv[1])
import handler as h  # noqa: E402

ARN = "arn:aws:dynamodb:us-east-1:111122223333:table/orders"
EVENT = {"detail": {"anomalyId": "a-1", "anomalyStartDate": "2026-11-09T00:00:00Z",
                    "rootCauses": [{"linkedAccount": "111122223333", "service": "Amazon DynamoDB",
                                    "usageType": "WriteCapacityUnit-Hrs", "region": "us-east-1"}]}}


def report(confidence, gaps=()):
    return {"summary": "s", "cause_category": "config_change", "root_cause": "r", "confidence": confidence,
            "confidence_rationale": "why", "baseline_daily_usd": 1, "spike_daily_usd": 9,
            "resources": [{"resource_id": ARN, "account_id": "111122223333", "region": "us-east-1",
                           "service": "AmazonDynamoDB", "usage_type": "WriteCapacityUnit-Hrs",
                           "baseline_daily_usd": 1, "spike_daily_usd": 9, "what_changed": "x"}],
            "evidence": [], "recommended_actions": [], "data_gaps": list(gaps)}


def tool_use(name, args):
    return {"usage": {"inputTokens": 100, "outputTokens": 10}, "stopReason": "tool_use",
            "output": {"message": {"role": "assistant", "content": [
                {"toolUse": {"toolUseId": "t", "name": name, "input": args}}]}}}


class Bedrock:
    def __init__(self, script):
        self.script, self.calls = list(script), []

    def converse(self, **kwargs):
        self.calls.append(kwargs)
        step = self.script.pop(0)
        if isinstance(step, Exception):
            raise step
        return step


class S3:
    def put_object(self, **kwargs):
        self.record = json.loads(kwargs["Body"])


class Context:
    def __init__(self, seconds):
        self.seconds = seconds

    def get_remaining_time_in_millis(self):
        return self.seconds * 1000


def athena(sql, max_rows=60):
    if "AS latest" in sql:
        return [{"latest": "2026-11-10 23:00:00.000"}]
    if "AS resource_id" in sql:
        return [{"resource_id": ARN, "product_code": "AmazonDynamoDB", "usage_type": "WriteCapacityUnit-Hrs",
                 "region": "us-east-1", "base_daily_usd": "1", "spike_daily_usd": "9", "line_item_types": "Usage",
                 "first_seen": "2026-10-26", "tags": '{"user_owner":"team@example.com"}'}]
    return [{"product_code": "AmazonDynamoDB", "usage_type": "x", "n": "1"}]


h.run_athena = athena
h.member_session = lambda account_id: object()
CHANGE = {"event_time": "2026-11-08T23:50:00+00:00", "event_name": "UpdateTable", "event_source": "dynamodb.amazonaws.com",
          "actor": "arn:aws:iam::1:user/alex", "error_code": None, "request_parameters": "{}"}
corroborated = {"value": True}   # whether CloudTrail backs up the cause
h.tool_lookup_cloudtrail = lambda *a, **k: (
    {"event_count": 1, "events": [CHANGE]} if corroborated["value"] else {"event_count": 0, "events": []})
h.tool_get_metric = lambda *a, **k: {"datapoints": []}
h.tool_get_config_history = lambda *a, **k: {"available": False, "reason": "off"}
h.tool_get_resource_tags = lambda *a, **k: {"tags": {ARN: {"Owner": "team@example.com"}}}
h.TOOL_FUNCTIONS.update(lookup_cloudtrail=h.tool_lookup_cloudtrail, query_cur=lambda sql: {"rows": athena(sql)})


def run(script, seconds=600):
    h.bedrock, h.s3 = Bedrock(script), S3()
    result = h.handler(json.loads(json.dumps(EVENT)), Context(seconds))
    return result, h.s3.record, h.bedrock.calls


def check(name, condition):
    print(("PASS" if condition else "FAIL"), name)
    if not condition:
        sys.exit(1)


# 1. Checklist is high confidence: one model call, no follow-up.
result, record, calls = run([tool_use("submit_report", report("high"))])
check("high: one model call", len(calls) == 1)
check("high: follow-up not needed", record["hybrid_stages"] == {"checklist_confidence": "high", "follow_up": "not_needed"})
check("high: owner resolved in code", record["report"]["resources"][0]["owner_contact"] == "team@example.com")

# 2. Checklist is medium: agent follows up with a tool, then submits high.
result, record, calls = run([
    tool_use("submit_report", report("medium", ["no CloudTrail event found"])),
    tool_use("lookup_cloudtrail", {"account_id": "111122223333", "region": "us-east-1", "attribute_key": "EventName",
                                   "attribute_value": "UpdateTable", "start_time": "2026-11-08T00:00:00Z",
                                   "end_time": "2026-11-11T00:00:00Z"}),
    tool_use("submit_report", report("high")),
])
stages = record["hybrid_stages"]
check("medium: three model calls", len(calls) == 3)
check("medium: follow-up completed", stages["follow_up"] == "completed" and stages["follow_up_tool_calls"] == 1)
check("medium: final confidence is the follow-up's", result["confidence"] == "high" and stages["checklist_confidence"] == "medium")
opening = calls[1]["messages"][0]["content"][0]["text"]
check("medium: follow-up sees evidence, first report and gap",
      "Checklist evidence:" in opening and "no CloudTrail event found" in opening and ARN in opening)
check("medium: follow-up has all tools", len(calls[1]["toolConfig"]["tools"]) == len(h.TOOLS))
check("medium: tokens summed over both stages", record["token_usage"]["inputTokens"] == 300)

# 3. Follow-up fails: checklist report is kept, gap recorded.
result, record, calls = run([tool_use("submit_report", report("low")), RuntimeError("bedrock down")])
check("failure: checklist report kept", result["confidence"] == "low" and record["hybrid_stages"]["follow_up"] == "failed")
check("failure: gap recorded", any("Agent follow-up failed" in g for g in record["report"]["data_gaps"]))

# 4. Too little time left: follow-up skipped.
result, record, calls = run([tool_use("submit_report", report("medium"))], seconds=60)
check("no time: skipped", len(calls) == 1 and record["hybrid_stages"]["follow_up"] == "skipped_no_time")
check("no time: gap recorded", any("skipped" in g for g in record["report"]["data_gaps"]))

# 5. Deadline passes mid follow-up: the next call is forced to submit.
h.FOLLOW_UP_MIN_SECONDS = -60
result, record, calls = run([tool_use("submit_report", report("medium")), tool_use("submit_report", report("medium"))],
                            seconds=h.TIME_RESERVE_SECONDS)
check("deadline: submit forced", calls[1]["toolConfig"].get("toolChoice") == {"tool": {"name": "submit_report"}})
h.FOLLOW_UP_MIN_SECONDS = 90

# 6. Checklist says high but nothing corroborates it: capped to medium, so the follow-up runs.
corroborated["value"] = False
result, record, calls = run([tool_use("submit_report", report("high")), tool_use("submit_report", report("medium"))])
check("uncorroborated: capped, then follow-up runs",
      record["hybrid_stages"]["checklist_confidence"] == "medium" and record["hybrid_stages"]["follow_up"] == "completed")
corroborated["value"] = True

# 7. single_shot still works after the refactor.
h.INVESTIGATION_MODE = "single_shot"
result, record, calls = run([tool_use("submit_report", report("high"))])
check("single_shot: unchanged", result["status"] == "complete" and record["hybrid_stages"] is None)
print("all checks passed")
