# CloudFormation deployment for the Organization

These templates replace `terraform/` for the enterprise Organization. The Lambda code in
`lambda/` is unchanged. `terraform/` and `scripts/demo.py` remain only for a sandbox.

**Status: linted and deployed once, in a single sandbox account.** `cfn-lint` 1.60.1 reports
no findings apart from the expected packaging notice (W3002). `pipeline.yaml` and
`member-role.yaml` deployed cleanly to a Pluralsight sandbox, and two anomalies ran end to end
through them (see "Sandbox test" at the end). Not exercised: `event-forwarder.yaml`, the
StackSet rollout, the Organization ID condition, a real CUR, real anomaly events, a KMS-encrypted
CUR, and email delivery. `cfn-guard` compliance checks were not run. Deploy first to a
non-critical account or with `TriggerState=DISABLED`.

## Templates

| Template | Where it goes | What it creates |
|---|---|---|
| `pipeline.yaml` | us-east-1 of the account that runs the pipeline | Bucket, dedupe table, Athena workgroup, three Lambda functions, state machine, EventBridge rule, IAM roles, FreshService settings |
| `member-role.yaml` | Every account, through a StackSet | The read-only role `FinOpsRcaReadOnly` |
| `event-forwarder.yaml` | us-east-1 of the management account, only if the pipeline runs elsewhere | A rule that forwards anomaly events to the pipeline account |

## What differs from the Terraform

- **No synthetic CUR.** The pipeline reads your existing CUR 2.0 table, given as parameters.
- **No demo tables and no simulated event source.** The rule matches real `aws.ce` events only.
  To replay a past anomaly, start the state machine directly (step 7).
- **The member role is a separate template** for a StackSet, and its trust is limited to the
  one investigation role.
- **Assuming the member role is limited to your Organization** by `aws:ResourceOrgID`.
- **The FreshService secret is created empty.** Terraform wrote a placeholder value.
- **Tighter defaults:** bucket versioning, encryption and TLS-only policy; log retention;
  point-in-time recovery on the dedupe table; SES sending limited to the one From address.
- **Default mode is `hybrid`** with a 600-second timeout, and `ShadowMode` defaults to `true`.

## Before you start

1. **Choose the account.** Cost Anomaly Detection emits its events in us-east-1 of the
   management account. Either deploy `pipeline.yaml` there, or deploy it in a tooling account
   and add `event-forwarder.yaml` in the management account.
2. **CUR access.** The pipeline account needs a Glue table over the CUR 2.0 export, partitioned
   by `billing_period`. If the export bucket is in another account, its bucket policy (and KMS
   key policy, if encrypted) must allow the role `<NamePrefix>-agent` to read it. If Lake
   Formation governs the table, grant that role `SELECT` on it; the template does not.
3. **Bedrock.** Enable access to the Claude model you will use, in us-east-1 of the pipeline
   account. Put its model ID or inference profile ID in `ModelId`.
4. **SES.** Verify the sending domain and move SES out of its sandbox, or mail can only reach
   verified addresses.
5. **StackSets.** Enable trusted access for CloudFormation StackSets in the Organization.
6. **An S3 bucket for deployment artifacts** in us-east-1 of the pipeline account. The package
   step uploads the Lambda code there.

## Deploy

### 1. Lint the templates

```bash
cfn-lint cloudformation/pipeline.yaml cloudformation/member-role.yaml cloudformation/event-forwarder.yaml
```

### 2. Fill in the parameters

Copy `parameters.example.json` to `parameters.json` and set the values. `parameters.json` is
git-ignored.

### 3. Package the Lambda code

```bash
aws cloudformation package --template-file cloudformation/pipeline.yaml --s3-bucket YOUR_ARTIFACT_BUCKET --s3-prefix finops-rca --output-template-file cloudformation/pipeline.packaged.yaml --region us-east-1
```

### 4. Deploy the pipeline

```bash
aws cloudformation deploy --template-file cloudformation/pipeline.packaged.yaml --stack-name finops-rca --capabilities CAPABILITY_NAMED_IAM --parameter-overrides file://cloudformation/parameters.json --region us-east-1
```

Repeat steps 3 and 4 after any change to the Lambda code.

### 5. Create the member role

Run this from the management account, or from a delegated administrator account with
`--call-as DELEGATED_ADMIN` added to each command.

```bash
aws cloudformation create-stack-set --stack-set-name finops-rca-member-role --template-body file://cloudformation/member-role.yaml --permission-model SERVICE_MANAGED --auto-deployment Enabled=true,RetainStacksOnAccountRemoval=false --capabilities CAPABILITY_NAMED_IAM --parameters ParameterKey=PipelineAccountId,ParameterValue=PIPELINE_ACCOUNT_ID --region us-east-1
```

Start with a few pilot accounts inside one organizational unit:

```bash
aws cloudformation create-stack-instances --stack-set-name finops-rca-member-role --deployment-targets OrganizationalUnitIds=OU_ID,Accounts=PILOT_ACCOUNT_1,PILOT_ACCOUNT_2,AccountFilterType=INTERSECTION --regions us-east-1 --region us-east-1
```

Later, extend to whole organizational units by running the same command with only
`OrganizationalUnitIds`. Use one region only: IAM roles are global.

A service-managed StackSet does not deploy to the management account. If spikes can occur
there, create the role in it as an ordinary stack:

```bash
aws cloudformation deploy --template-file cloudformation/member-role.yaml --stack-name finops-rca-member-role --capabilities CAPABILITY_NAMED_IAM --parameter-overrides PipelineAccountId=PIPELINE_ACCOUNT_ID --region us-east-1
```

### 6. Forward events (only if the pipeline is not in the management account)

Deploy the pipeline with `EventSourceAccountId` set to the management account ID, then run this
in the management account:

```bash
aws cloudformation deploy --template-file cloudformation/event-forwarder.yaml --stack-name finops-rca-event-forwarder --capabilities CAPABILITY_IAM --parameter-overrides PipelineAccountId=PIPELINE_ACCOUNT_ID --region us-east-1
```

### 7. Replay a past anomaly

Copy `sample-anomaly-event.json`, fill in a real past anomaly, and start the state machine with
it. `ShadowMode=true` keeps the result within FinOps.

```bash
aws stepfunctions start-execution --state-machine-arn STATE_MACHINE_ARN --input file://cloudformation/my-anomaly.json --region us-east-1
```

The state machine ARN is the `StateMachineArn` output of the pipeline stack. The report is
saved under `reports/` in the bucket named by the `DataBucketName` output.

### 8. FreshService (optional)

Put the API key in the secret named by the `FreshServiceSecretArn` output, then set the SSM
parameter `/finops-rca/freshservice/enabled` to `true`.

## Things to check on the first run

- **The real event format.** `sample-anomaly-event.json` shows the fields the code reads. They
  came from documentation; compare them with a real event from your account.
- **The scan limit.** `AthenaBytesScannedCutoff` defaults to 100 GB per query. If your CUR is
  larger, queries are cancelled and the investigation fails or reports gaps.
- **The `ses:FromAddress` condition** on the notify role. If email fails with an access error,
  this is the first place to look.
- **Removing the stack** leaves the bucket, the dedupe table and the secret in place on purpose.

## Sandbox test

`sandbox/fixture.yaml` creates stand-ins for what the Organization already has: a bucket and
Glue table for synthetic CUR data, and two demo DynamoDB tables. **Never deploy it in the
Organization.** With it, the templates can be tested in a throwaway account:

```bash
aws cloudformation deploy --template-file cloudformation/sandbox/fixture.yaml --stack-name finops-rca-sandbox-fixture --profile YOUR_PROFILE --region us-east-1
```

Then package and deploy `pipeline.yaml` (steps 3 and 4) with the fixture's outputs as
`CurDatabase`, `CurTable` and `CurBucketName`, `CurPrefix=cur/`, and `OrganizationId` left
empty. Deploy `member-role.yaml` as an ordinary stack in the same account. The demo script then
drives it:

```bash
py scripts/demo.py --cfn-profile YOUR_PROFILE load-cur
```

```bash
py scripts/demo.py --cfn-profile YOUR_PROFILE change
```

Wait about five minutes for CloudTrail, then:

```bash
py scripts/demo.py --cfn-profile YOUR_PROFILE fire orders
```

Scenarios: `orders`, `sessions`, `savingsplan`, `autoscale`, `datatransfer`. Finish with
`revert` to put the demo tables back to 5 capacity units.

Results of the one sandbox test (Haiku 4.5, `hybrid` mode, 60-second timeout):

| Scenario | Time | Tokens | Result |
|---|---|---|---|
| `orders` | 17 s | 8,052 | Correct: capacity raised on the tagged table, by whom and when; routed to the owner |
| `autoscale` | 19 s | 8,702 | Correct group and size (2 to 12 instances); routed to the owner. It claimed high confidence with no corroborating evidence, which led to the confidence cap now in the code |

Three fixes came out of that test and are in the code, but were not re-run with the model
because the sandbox's 20,000-token limit was nearly used up: a minimum increase before a
resource counts as rising, the confidence cap when nothing but the CUR supports the cause, and
two added instructions to the model.
