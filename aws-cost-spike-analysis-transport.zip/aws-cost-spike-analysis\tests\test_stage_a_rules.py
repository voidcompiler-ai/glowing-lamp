"""Local test of the Stage A rules with every AWS call stubbed. No AWS access, no tokens."""
import json
import os
import sys

os.environ.update(MODEL_ID="stub", BUCKET="b", ATHENA_WORKGROUP="w", CUR_DATABASE="d", CUR_TABLE="cur2",
                  MEMBER_ROLE_NAME="r", INVESTIGATION_MODE="single_shot", AWS_DEFAULT_REGION="us-east-1",
                  AWS_ACCESS_KEY_ID="x", AWS_SECRET_ACCESS_KEY="x", AWS_EC2_METADATA_DISABLED="true")
sys.path.insert(0, sys.argv[1])
import handler as h  # noqa: E402

ACCOUNT = "111122223333"
ARN = f"arn:aws:%s:us-east-1:{ACCOUNT}:%s"
NAT = ARN % ("ec2", "natgateway/nat-0abc")
ALB = ARN % ("elasticloadbalancing", "loadbalancer/app/web/50dc6c495c0c9188")
LOGS = ARN % ("logs", "log-group:/aws/lambda/orders:*")


def check(name, condition):
    print(("PASS" if condition else "FAIL"), name)
    if not condition:
        sys.exit(1)


def plan(resource_id, product):
    found = h._metric_plan(resource_id, product, ACCOUNT)
    return found and (found["namespace"], found["dimensions"][0]["name"], found["dimensions"][0]["value"])


# --- which metrics are read for which resource ---
for label, resource_id, product, expected in [
    ("NAT gateway", NAT, "AmazonEC2", ("AWS/NATGateway", "NatGatewayId", "nat-0abc")),
    ("transit gateway", ARN % ("ec2", "transit-gateway/tgw-01"), "AmazonVPC", ("AWS/TransitGateway", "TransitGateway", "tgw-01")),
    ("ALB", ALB, "AWSELB", ("AWS/ApplicationELB", "LoadBalancer", "app/web/50dc6c495c0c9188")),
    ("NLB", ARN % ("elasticloadbalancing", "loadbalancer/net/tcp/12"), "AWSELB", ("AWS/NetworkELB", "LoadBalancer", "net/tcp/12")),
    ("Classic ELB", ARN % ("elasticloadbalancing", "loadbalancer/old"), "AWSELB", ("AWS/ELB", "LoadBalancerName", "old")),
    ("CloudFront", f"arn:aws:cloudfront::{ACCOUNT}:distribution/E123", "AmazonCloudFront", ("AWS/CloudFront", "DistributionId", "E123")),
    ("log group", LOGS, "AmazonCloudWatch", ("AWS/Logs", "LogGroupName", "/aws/lambda/orders")),
    ("Aurora cluster", ARN % ("rds", "cluster:shop"), "AmazonRDS", ("AWS/RDS", "DBClusterIdentifier", "shop")),
    ("RDS instance", ARN % ("rds", "db:shop-1"), "AmazonRDS", ("AWS/RDS", "DBInstanceIdentifier", "shop-1")),
    ("EFS", ARN % ("elasticfilesystem", "file-system/fs-01"), "AmazonEFS", ("AWS/EFS", "FileSystemId", "fs-01")),
    ("S3 bucket", "my-bucket", "AmazonS3", ("AWS/S3", "BucketName", "my-bucket")),
    ("Lambda with version", ARN % ("lambda", "function:orders:3"), "AWSLambda", ("AWS/Lambda", "FunctionName", "orders")),
    ("SQS queue", ARN % ("sqs", "jobs"), "AWSQueueService", ("AWS/SQS", "QueueName", "jobs")),
    ("EC2 instance", "i-0123", "AmazonEC2", ("AWS/EC2", "InstanceId", "i-0123")),
    ("DynamoDB table", ARN % ("dynamodb", "table/orders"), "AmazonDynamoDB", ("AWS/DynamoDB", "TableName", "orders")),
    ("EBS volume (no metrics)", "vol-0123", "AmazonEC2", None),
    ("unknown service (no metrics)", "thing-1", "AmazonMystery", None),
]:
    check(f"metrics: {label}", plan(resource_id, product) == expected)
check("metrics: S3 is read daily", h._metric_plan("my-bucket", "AmazonS3")["period"] == 86400)
check("metrics: CloudFront is read in us-east-1", h._metric_plan(f"arn:aws:cloudfront::{ACCOUNT}:distribution/E1", "AmazonCloudFront")["region"] == "us-east-1")


# --- end-to-end Stage A with stubs ---
class Bedrock:
    def converse(self, **kwargs):
        self.prompt = kwargs["system"][0]["text"]
        self.evidence = json.loads(kwargs["messages"][0]["content"][0]["text"].split("\n", 1)[1])
        report = {"summary": "s", "cause_category": "usage_growth", "root_cause": "r", "confidence": "high",
                  "confidence_rationale": "why", "baseline_daily_usd": 1, "spike_daily_usd": 9, "resources": [],
                  "evidence": [], "recommended_actions": [], "data_gaps": []}
        return {"usage": {"inputTokens": 1, "outputTokens": 1}, "stopReason": "tool_use",
                "output": {"message": {"role": "assistant", "content": [
                    {"toolUse": {"toolUseId": "t", "name": "submit_report", "input": report}}]}}}


class S3:
    def put_object(self, **kwargs):
        self.record = json.loads(kwargs["Body"])


def event(usage_type):
    return {"detail": {"anomalyId": "a-1", "anomalyStartDate": "2026-11-09T00:00:00Z",
                       "rootCauses": [{"linkedAccount": ACCOUNT, "service": "x",
                                       "usageType": usage_type, "region": "us-east-1"}]}}


state = {}


def athena(sql, max_rows=60):
    state["sql"].append(sql)
    if "AS latest" in sql:
        return [{"latest": "2026-11-10 23:00:00.000"}]
    if state.get("extras_fail") and any(marker in sql for marker in ("AS day", "AS operation", "AS kind", "SELECT product_region_code")):
        raise RuntimeError("Athena query FAILED: syntax")
    if "AS kind" in sql:
        return state.get("groups", [])
    if "AS day" in sql:
        return [{"day": "2026-11-10", "usd": "9", "usage": "9", "resources": "40"},
                {"day": "2026-11-08", "usd": "1", "usage": "1", "resources": "2"},
                {"day": "2026-11-09", "usd": "9", "usage": "9", "resources": "40"}]
    if "AS operation" in sql:
        return [{"operation": "InterZone-Out", "region": "us-east-1", "description": "regional data transfer",
                 "base_daily_usd": "1", "spike_daily_usd": "50", "base_daily_usage": "100", "spike_daily_usage": "5000"}]
    if sql.startswith("SELECT product_region_code"):
        return [{"region": "ap-south-1", "product_code": "AmazonEC2", "base_daily_usd": "0", "spike_daily_usd": "80"}]
    if "AS resource_id" in sql:
        if "line_item_usage_type = " in sql and state.get("no_scoped"):
            return []
        return [{"resource_id": rid, "product_code": state["product"], "usage_type": state["usage_type"],
                 "region": "us-east-1", "base_daily_usd": "0", "spike_daily_usd": "3", "line_item_types": "Usage",
                 "first_seen": "2026-11-09", "last_seen": "2026-11-10", "tags": '{"user_owner":"team@example.com"}'}
                for rid in state["resources"]]
    return [{"product_code": state["product"], "usage_type": state["usage_type"], "line_item_type": "Usage"}]


def cloudtrail(account_id, region, key, value, start, end, max_events=40, pages=4):
    state["trail"].append((key, value, region))
    def ev(name, actor, params="{}"):
        return {"event_time": "2026-11-08T23:50:00+00:00", "event_name": name, "event_source": value,
                "actor": actor, "error_code": None, "request_parameters": params}
    if value == "autoscaling.amazonaws.com":
        events = [ev("UpdateAutoScalingGroup", "arn:aws:iam::1:user/alex", '{"autoScalingGroupName":"web-asg","maxSize":60}'),
                  ev("PutScalingPolicy", "x", '{"autoScalingGroupName":"other"}')]
    elif value == "ec2.amazonaws.com":
        events = [ev("RunInstances", f"arn:aws:sts::1:assumed-role/deploy/session-{n}") for n in range(3)]
        events.append(ev("CreateTags", "arn:aws:iam::1:user/alex"))
    else:
        events = []
    return {"event_count": len(events), "events": events}


def metric(account_id, region, namespace, name, dimensions, start, end, statistic="Average", period=3600):
    state["metrics"].append((namespace, name, dimensions[0]["value"], period, region))
    return {"datapoints": []}


def member(account_id):
    if state.get("no_member"):
        h._note_gap(f"Could not assume r in account {account_id} (AccessDenied); member-account evidence unavailable")
        raise RuntimeError("AccessDenied")
    return object()


h.run_athena = athena
h.member_session = member
h.tool_lookup_cloudtrail = cloudtrail
h.tool_get_metric = metric
h.tool_get_config_history = lambda *a, **k: {"available": False, "reason": "off"}
h.tool_get_resource_tags = lambda *a, **k: {"tags": {}}


def run(usage_type, resources, product="AmazonEC2", **flags):
    state.clear()
    state.update(sql=[], trail=[], metrics=[], usage_type=usage_type, resources=resources, product=product, **flags)
    h.bedrock, h.s3 = Bedrock(), S3()
    result = h.handler(event(usage_type), None)
    return result, h.bedrock.evidence, h.s3.record


ASG = [{"kind": "auto_scaling_group", "name": "web-asg", "members": "40", "region": "us-east-1", "base_daily_usd": "0",
        "spike_daily_usd": "120", "first_seen": "2026-11-09 02:00:00", "last_seen": "2026-11-10 06:00:00"}]

# 1. Cost spread over Auto Scaling instances.
result, evidence, record = run("BoxUsage:m5.large", ["i-01", "i-02", "i-03", "i-04"], groups=ASG)
group = evidence["resource_groups"][0]
check("group: parent total reaches Claude", group["name"] == "web-asg" and group["members"] == "40")
events = group["evidence"]["cloudtrail_write_events"]
check("group: only this group's change is kept", len(events) == 1 and "maxSize" in events[0]["request_parameters"])
check("group: CloudTrail searched by name and by event source",
      ("ResourceName", "web-asg", "us-east-1") in state["trail"]
      and ("EventSource", "autoscaling.amazonaws.com", "us-east-1") in state["trail"])
check("group: size and CPU metrics read",
      {("AWS/AutoScaling", "GroupDesiredCapacity", "web-asg"), ("AWS/EC2", "CPUUtilization", "web-asg")}
      <= {m[:3] for m in state["metrics"]})
group_sql = next(s for s in state["sql"] if "AS kind" in s)
check("group: roll-up scoped to the anomaly usage type", "line_item_usage_type = 'BoxUsage:m5.large'" in group_sql)
check("group: instance evidence still gathered for top 3", len(evidence["resource_evidence"]) == 3)

check("confidence: stays high when a change event backs it up", result["confidence"] == "high")

# 2. Change summary: who did what in the service.
summary = evidence["change_summary"]
top = summary["by_event_and_principal"][0]
check("changes: counted by event and principal", top["event_name"] == "RunInstances" and top["count"] == 3)
check("changes: role sessions collapsed to the role", top["principal"].endswith("assumed-role/deploy"))
check("changes: service taken from the top resource", summary["event_source"] == "ec2.amazonaws.com")

# 3. Trend, operation and region breakdowns reach Claude.
check("trend: days in order", [row["day"] for row in evidence["daily_trend"]] == ["2026-11-08", "2026-11-09", "2026-11-10"])
check("detail: by operation", evidence["usage_type_detail"][0]["operation"] == "InterZone-Out")
check("regions: new region listed", evidence["region_breakdown"][0]["region"] == "ap-south-1")
check("prompt explains every section", all(key in h.bedrock.prompt for key in (
    "cost_breakdown", "daily_trend", "usage_type_detail", "region_breakdown", "top_resources", "resource_groups",
    "change_summary", "resource_evidence")))

# 4. Every extra query fails: Stage A still completes and lists the gaps.
result, evidence, record = run("BoxUsage:m5.large", ["i-01"], extras_fail=True)
gaps = record["report"]["data_gaps"]
check("extras fail: investigation completes", result["status"] == "complete" and "daily_trend" not in evidence)
check("extras fail: four gaps recorded", sum("could not be read from the CUR" in g for g in gaps) == 4)

# 5. Data transfer through a NAT gateway and a load balancer; log ingestion; S3 storage.
result, evidence, record = run("NatGateway-Bytes", [NAT])
check("confidence: capped at medium when nothing but the CUR supports the cause",
      result["confidence"] == "medium" and "Capped at medium" in record["report"]["confidence_rationale"])
check("nat: bytes read", ("AWS/NATGateway", "BytesOutToDestination", "nat-0abc") in {m[:3] for m in state["metrics"]})
run("DataTransfer-Out-Bytes", [ALB], product="AWSELB")
check("alb: processed bytes read", ("AWS/ApplicationELB", "ProcessedBytes") in {m[:2] for m in state["metrics"]})
check("alb: change summary uses the load balancer service", ("EventSource", "elasticloadbalancing.amazonaws.com", "us-east-1") in state["trail"])
run("DataProcessing-Bytes", [LOGS], product="AmazonCloudWatch")
check("logs: incoming bytes read", ("AWS/Logs", "IncomingBytes", "/aws/lambda/orders") in {m[:3] for m in state["metrics"]})
run("TimedStorage-ByteHrs", ["my-bucket"], product="AmazonS3")
check("s3: bucket size read daily", ("AWS/S3", "BucketSizeBytes", "my-bucket", 86400) in {m[:4] for m in state["metrics"]})

# 6. Usage type with no resource IDs.
result, evidence, record = run("DataTransfer-Regional-Bytes", ["vol-01"], no_scoped=True)
check("no ids: gap says ranking covers the whole account",
      any("covers the whole account" in g for g in record["report"]["data_gaps"]))
check("no ids: operation breakdown still present", "usage_type_detail" in evidence)

# 7. No resources at all (for example a tax or support fee line).
result, evidence, record = run("Tax", [], product="AWSSupport")
check("no resources: completes without member lookups on resources",
      result["status"] == "complete" and "top_resources" not in evidence and "resource_evidence" not in evidence)

# 8. Member account cannot be read.
result, evidence, record = run("BoxUsage:m5.large", ["i-01"], no_member=True)
check("no member access: evidence marked unavailable", evidence["resource_evidence"].startswith("unavailable"))
check("no member access: confidence capped", result["confidence"] == "medium")
print("all checks passed")
